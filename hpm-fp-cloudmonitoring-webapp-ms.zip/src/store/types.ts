/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/

export const SET_LIST = 'SET_LIST';
export const GET_LIST = 'GET_LIST';
export const SET_TOGGLE_HISTORY_VIEW = 'SET_TOGGLE_HISTORY_VIEW';
export const PAGE_CHANGED = 'PAGE_CHANGED';
export const PAGE_SIZE_CHANGED = 'PAGE_SIZE_CHANGED';
export const TOTAL_COUNT_CHANGED = 'TOTAL_COUNT_CHANGED';
export const SEARCH = 'SEARCH';
export const SET_SORTING = 'SET_SORTING';
export const SET_APPLICATION_LIST = 'SET_APPLICATION_LIST';
export const SET_APPLICATION_NAME = 'SET_APPLICATION_NAME';
export const SET_MONTHLY_DATA = 'SET_MONTHLY_DATA';
export const SET_TENANT_CONNECTION_LIST = 'SET_TENANT_CONNECTION_LIST';
export const SET_DATEWISE_CLOUD_STATUS = 'SET_DATEWISE_CLOUD_STATUS';
export const TABLE_PAGE_CHANGED = 'TABLE_PAGE_CHANGED';
export const TABLE_PAGE_SIZE_CHANGED = 'TABLE_PAGE_SIZE_CHANGED';
export const TABLE_TOTAL_COUNT_CHANGED = 'TABLE_TOTAL_COUNT_CHANGED';
export const SET_TOGGLE_TENANT_HISTORY_VIEW = 'SET_TOGGLE_TENANT_HISTORY_VIEW';
export const SET_TENANT_NAME_LIST = 'SET_TENANT_NAME_LIST';
export const SET_TENANT_ID = 'SET_TENANT_ID';
export const SET_TENANT_DAYWISE_STATUS = 'SET_TENANT_DAYWISE_STATUS';
export const SET_DOWN_TIME_STATUS = 'SET_DOWN_TIME_STATUS';
export const SET_DATE = 'SET_DATE';
export const SET_SEARCH_RESULT_STATUS = 'SET_SEARCH_RESULT_STATUS';
export const SET_TENANT_SORT = 'SET_TENANT_SORT';
export const SET_SHOW_TENANT_SEARCH_STATUS = 'SET_SHOW_TENANT_SEARCH_STATUS';
export const SET_SEARCH_TENANT = 'SET_SEARCH_TENANT';
export const SET_USERPREFERENCE_LIST = 'SET_USERPREFERENCE_LIST';
export const USER_PAGE_CHANGED = 'USER_PAGE_CHANGED';
export const USER_PAGE_SIZE_CHANGED = 'USER_PAGE_SIZE_CHANGED';
export const USER_TOTAL_COUNT_CHANGED = 'USER_TOTAL_COUNT_CHANGED';
export const CHECKED = 'CHECKED';
export const PREFERENCE_ID = 'PREFERENCE_ID';
export const SET_USER_SORT = 'SET_USER_SORT';
export const SET_USER_SEARCH_RESULT_STATUS = 'SET_USER_SEARCH_RESULT_STATUS';
export const SET_SEARCH_APPLICATION_NAME = 'SET_SEARCH_APPLICATION_NAME';
export const TENANT_LICENSE_ID = 'TENANT_LICENSE_ID';
export const LICENSE_NAME = 'LICENSE_NAME';
export const PRODUCT_VERSION = 'PRODUCT_VERSION';
export const BED_DETAILS = 'BED_DETAILS';
export const ACTIVATION_DATE = 'ACTIVATION_DATE';
export const SET_LICENSE_DATA = 'SET_LICENSE_DATA';
export const LICENSE_PAGE_CHANGED = 'LICENSE_PAGE_CHANGED';
export const LICENSE_PAGE_SIZE_CHANGED = 'LICENSE_PAGE_SIZE_CHANGED';
export const LICENSE_TOTAL_COUNT_CHANGED = 'LICENSE_TOTAL_COUNT_CHANGED';
export const SET_LICENSE_SORTING = 'SET_LICENSE_SORTING';
export const SET_LICENSE_NAME = 'SET_LICENSE_NAME';
export const RESET_LICENSCE_STATE = 'RESET_LICENSCE_STATE';
export const RESET_USER_STATE = 'RESET_USER_STATE';
export const RESET_LIST_STATE = 'RESET_LIST_STATE';

export type HealthStatusResponse = ApplicationInfo[];
export interface ApplicationInfo {
	tenantId: string,
	applicationName: string,
	displayName: string,
	totalRecords: string,
	status: StatusInfo[]

}
export interface StatusInfo {
	date: string,
	status: string
}
export interface DownTimeStatus {
	from: string,
	to: string
	duration: string,
}
export type ApplicationList = AppList[];
export interface AppList {
	applicationName: string,
	displayName: string
}

export type TenantStatusResponse = TenantInfo[];
export interface TenantInfo {
	tenantId: string,
	totalRecords: string,
	status: TenantStatusInfo[],
	tenantName: string,
	iscloudEnabled: boolean,

}
export interface TenantStatusInfo {
	applicationName: string,
	displayName: string,
	status: string
}
export type TenantList = TenantNameList[];
export type UserPreferenceList = [];
export interface TenantNameList {
	tenantName: string,
	isCloudEnabled: boolean,
	tenantId: string
}
export type LicenseList = License[];

export interface License {
	tenantName: string,
	licenseType: string,
	productVersion: string,
	bedDetails: number,
	activationDate: string,
}
export type LicenseDetailResponse = LicenseInfo[];
export interface LicenseInfo {
	tenantLicenseId: string,
	LicenseName: string,
	productVerison: string,
	BedDetails: number,
	activationDate: number
}


//Actions
interface SetListAction {
	type: typeof SET_LIST,
	payload: HealthStatusResponse
}
interface GetListAction {
	type: typeof GET_LIST
}

interface SetToggleHistoryView {
	type: typeof SET_TOGGLE_HISTORY_VIEW,
	payload: boolean
}

interface SetPage {
	type: typeof PAGE_CHANGED,
	payload: number
}
interface SetPageSize {
	type: typeof PAGE_SIZE_CHANGED,
	payload: number
}
interface SetTotalCount {
	type: typeof TOTAL_COUNT_CHANGED,
	payload: number
}
interface IsSearch {
	type: typeof SEARCH,
	payload: boolean
}
interface SetSorting {
	type: typeof SET_SORTING,
	payload: string
}
interface SetApplicationList {
	type: typeof SET_APPLICATION_LIST,
	payload: ApplicationList
}
interface SetApplicationName {
	type: typeof SET_APPLICATION_NAME,
	payload: string
}
interface TenantStatusList {
	type: typeof SET_TENANT_CONNECTION_LIST,
	payload: TenantStatusResponse
}
interface SetDatewiseStatus {
	type: typeof SET_DATEWISE_CLOUD_STATUS,
	payload: boolean
}
interface SetTenantPage {
	type: typeof TABLE_PAGE_CHANGED,
	payload: number
}
interface SetTenantPageSize {
	type: typeof TABLE_PAGE_SIZE_CHANGED,
	payload: number
}
interface SetTenantTotalCount {
	type: typeof TABLE_TOTAL_COUNT_CHANGED,
	payload: number
}
interface SetToggleTenantHistoryView {
	type: typeof SET_TOGGLE_TENANT_HISTORY_VIEW,
	payload: boolean
}
interface SetTenantNameList {
	type: typeof SET_TENANT_NAME_LIST,
	payload: TenantList
}
interface SetTenantId {
	type: typeof SET_TENANT_ID,
	payload: string
}
interface SetTenantDaywiseStatus {
	type: typeof SET_TENANT_DAYWISE_STATUS,
	payload: boolean
}
interface SetDownTimeStatus {
	type: typeof SET_DOWN_TIME_STATUS,
	payload: boolean
}
interface SetDate {
	type: typeof SET_DATE,
	payload: string
}
interface SearchResultStatus {
	type: typeof SET_SEARCH_RESULT_STATUS,
	payload: boolean
}
interface SetTenantSort {
	type: typeof SET_TENANT_SORT,
	payload: string
}
interface ShowTenantSearchResult {
	type: typeof SET_SHOW_TENANT_SEARCH_STATUS,
	payload: boolean
}
interface SetUserPreferenceList {
	type: typeof SET_USERPREFERENCE_LIST,
	payload: UserPreferenceList
}

interface SetUserPage {
	type: typeof USER_PAGE_CHANGED,
	payload: number
}
interface SetUserPageSize {
	type: typeof USER_PAGE_SIZE_CHANGED,
	payload: number
}
interface SetUserTotalCount {
	type: typeof USER_TOTAL_COUNT_CHANGED,
	payload: number
}
interface SetChecked {
	type: typeof CHECKED,
	payload: boolean
}
interface SetPreferenceId {
	type: typeof PREFERENCE_ID,
	payload: string
}
interface SetUserSort {
	type: typeof SET_USER_SORT,
	payload: string
}

interface SetUserSearchResultStatus {
	type: typeof SET_USER_SEARCH_RESULT_STATUS,
	payload: boolean
}
interface SetSearchApplication {
	type: typeof SET_SEARCH_APPLICATION_NAME,
	payload: string
}
interface TenantLicenseId {
	type: typeof TENANT_LICENSE_ID,
	payload: string
}
interface SetTenantSearch {
	type: typeof SET_SEARCH_TENANT,
	payload: string
}
interface LicenseName {
	type: typeof LICENSE_NAME,
	payload: string
}
interface ProductVersion {
	type: typeof PRODUCT_VERSION,
	payload: string
}
interface BedDetails {
	type: typeof BED_DETAILS,
	payload: number
}
interface ActivationDate {
	type: typeof ACTIVATION_DATE,
	payload: number
}
interface SetLicenseData {
	type: typeof SET_LICENSE_DATA,
	payload: LicenseList
}
interface SetLicensePage {
	type: typeof LICENSE_PAGE_CHANGED,
	payload: number
}
interface SetLicensePageSize {
	type: typeof LICENSE_PAGE_SIZE_CHANGED,
	payload: number
}
interface SetLicenseTotalCount {
	type: typeof LICENSE_TOTAL_COUNT_CHANGED,
	payload: number
}
interface SetLicenseSorting {
	type: typeof SET_LICENSE_SORTING,
	payload: string
}
interface SetLicenseName {
	type: typeof SET_LICENSE_NAME,
	payload: string
}
interface ResetLicenseState {
	type: typeof RESET_LICENSCE_STATE,
}
interface ResetUserState {
	type: typeof RESET_USER_STATE,
}
interface ResetListState {
	type: typeof RESET_LIST_STATE,
}

export type ListsAction = GetListAction | SetListAction | SetToggleHistoryView | SetPage | SetPageSize | SetTotalCount | IsSearch | SetSorting | SetApplicationList | SetApplicationName | TenantStatusList | SetDatewiseStatus | SetTenantPage | SetTenantPageSize | SetTenantTotalCount | SetToggleTenantHistoryView | SetTenantNameList | SetTenantId | SetTenantDaywiseStatus | SetDownTimeStatus | SetDate | SearchResultStatus | SetTenantSort | ShowTenantSearchResult | SetUserPreferenceList | SetUserPage | SetUserPageSize | SetUserTotalCount | SetChecked | SetPreferenceId | SetUserSort | SetUserSearchResultStatus | SetSearchApplication | TenantLicenseId | LicenseName | ProductVersion | BedDetails | ActivationDate | SetLicenseData | SetLicensePage | SetLicensePageSize | SetLicenseTotalCount | SetLicenseSorting | SetLicenseName | ResetLicenseState | ResetListState | ResetUserState | SetTenantSearch;

export interface ListStates {
	lists: HealthStatusResponse,
	status: boolean,
	queryPageIndex: number,
	queryPageSize: number,
	totalCount: number,
	isSearch: boolean,
	sort: string,
	appList: ApplicationList,
	selectedApplication: string,
	tenantList: TenantStatusResponse,
	dateWiseStatus: boolean,
	pageIndex: number,
	pageSize: number,
	totalTenant: number,
	tenantStatus: boolean,
	tenantNameList: TenantList,
	selectedTenant: string,
	showDaywiseStatus: boolean,
	showDownTimeStatus: boolean,
	selectedDate: string,
	displayStatus: boolean,
	tenantSort: string,
	tenantSearchResult: boolean,
	searchApplication: string;
	searchTenant: string;
}
export interface UserPreferenceState {
	userPreferenceList: UserPreferenceList,
	userPageIndex: number,
	userPageSize: number,
	totalUserPeference: number,
	checked: boolean,
	preferenceId: string,
	userSort: string,
	userSerachStatus: boolean
}
export interface LicenseDetailsState {
	tenantLicenseId: string,
	licenseName: string,
	productVerison: string,
	bedDetails: number,
	activationDate: number,
	licenseList: LicenseList,
	licensePageIndex: number,
	totalLicense: number,
	licenseSort: string,
	licensePageSize: number
	searchLicense: string;
}