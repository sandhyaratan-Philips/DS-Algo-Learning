/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/

import {
	ListsAction, HealthStatusResponse, GET_LIST, SET_LIST, SET_TOGGLE_HISTORY_VIEW, PAGE_CHANGED, PAGE_SIZE_CHANGED, TOTAL_COUNT_CHANGED, SEARCH, SET_SORTING, SET_APPLICATION_LIST, ApplicationList, SET_APPLICATION_NAME, SET_TENANT_CONNECTION_LIST, TenantStatusResponse, SET_DATEWISE_CLOUD_STATUS, TABLE_PAGE_CHANGED, TABLE_PAGE_SIZE_CHANGED, TABLE_TOTAL_COUNT_CHANGED, SET_TOGGLE_TENANT_HISTORY_VIEW, SET_TENANT_NAME_LIST, TenantList, SET_TENANT_ID, SET_TENANT_DAYWISE_STATUS, SET_DOWN_TIME_STATUS, SET_DATE,
	SET_SEARCH_RESULT_STATUS, SET_SEARCH_TENANT, RESET_LICENSCE_STATE, RESET_LIST_STATE, RESET_USER_STATE, SET_LICENSE_NAME, SET_TENANT_SORT, SET_SHOW_TENANT_SEARCH_STATUS, SET_USERPREFERENCE_LIST, USER_PAGE_CHANGED, CHECKED, PREFERENCE_ID, USER_TOTAL_COUNT_CHANGED, USER_PAGE_SIZE_CHANGED, SET_USER_SORT, UserPreferenceList, SET_USER_SEARCH_RESULT_STATUS, SET_SEARCH_APPLICATION_NAME, TENANT_LICENSE_ID, LICENSE_NAME, PRODUCT_VERSION, BED_DETAILS, SET_LICENSE_DATA, ACTIVATION_DATE, LicenseList, LICENSE_PAGE_CHANGED, LICENSE_PAGE_SIZE_CHANGED, LICENSE_TOTAL_COUNT_CHANGED, SET_LICENSE_SORTING
} from "../types";

export const setList = (list: HealthStatusResponse): ListsAction => {
	return {
		type: SET_LIST,
		payload: list
	}
}

export const getList = (): ListsAction => {
	return {
		type: GET_LIST
	}
}

export const setToggleHistoryView = (status: boolean): ListsAction => {
	return {
		type: SET_TOGGLE_HISTORY_VIEW,
		payload: status
	}
}
export const SetPage = (page: number): ListsAction => {
	return {
		type: PAGE_CHANGED,
		payload: page

	}
}
export const SetPageSize = (page: number): ListsAction => {
	return {
		type: PAGE_SIZE_CHANGED,
		payload: page

	}
}

export const SetTotalCount = (page: number): ListsAction => {
	return {
		type: TOTAL_COUNT_CHANGED,
		payload: page

	}
}

export const IsSearch = (isSearch: boolean): ListsAction => {
	return {
		type: SEARCH,
		payload: isSearch
	}
}

export const SetSorting = (sort: string): ListsAction => {
	return {
		type: SET_SORTING,
		payload: sort

	}
}

export const setApplicationList = (applist: ApplicationList): ListsAction => {
	return {
		type: SET_APPLICATION_LIST,
		payload: applist
	}
}

export const setApplicationName = (selectedApplication: string): ListsAction => {
	return {
		type: SET_APPLICATION_NAME,
		payload: selectedApplication
	}
}

export const TenantStatusList = (tenantList: TenantStatusResponse): ListsAction => {
	return {
		type: SET_TENANT_CONNECTION_LIST,
		payload: tenantList
	}
}

export const SetDatewiseStatus = (dateWiseStatus: boolean): ListsAction => {
	return {
		type: SET_DATEWISE_CLOUD_STATUS,
		payload: dateWiseStatus
	}
}

export const SetTenantPage = (page: number): ListsAction => {
	return {
		type: TABLE_PAGE_CHANGED,
		payload: page

	}
}

export const SetTenantPageSize = (page: number): ListsAction => {
	return {
		type: TABLE_PAGE_SIZE_CHANGED,
		payload: page

	}
}
export const SetTenantTotalCount = (page: number): ListsAction => {
	return {
		type: TABLE_TOTAL_COUNT_CHANGED,
		payload: page

	}
}
export const SetToggleTenantHistoryView = (tenantStatus: boolean): ListsAction => {
	return {
		type: SET_TOGGLE_TENANT_HISTORY_VIEW,
		payload: tenantStatus
	}
}

export const SetTenantNameList = (tenantNameList: TenantList): ListsAction => {
	return {
		type: SET_TENANT_NAME_LIST,
		payload: tenantNameList
	}
}
export const SetTenantId = (selectedTenant: string): ListsAction => {
	return {
		type: SET_TENANT_ID,
		payload: selectedTenant
	}
}
export const SetTenantDaywiseStatus = (showDaywiseStatus: boolean): ListsAction => {
	return {
		type: SET_TENANT_DAYWISE_STATUS,
		payload: showDaywiseStatus
	}
}
export const SetDownTimeStatus = (showDownTimeStatus: boolean): ListsAction => {
	return {
		type: SET_DOWN_TIME_STATUS,
		payload: showDownTimeStatus
	}
}
export const SetDate = (selectedDate: string): ListsAction => {
	return {
		type: SET_DATE,
		payload: selectedDate
	}
}

export const SearchResultStatus = (displayStatus: boolean): ListsAction => {
	return {
		type: SET_SEARCH_RESULT_STATUS,
		payload: displayStatus
	}
}
export const SetTenantSort = (tenantSort: string): ListsAction => {
	return {
		type: SET_TENANT_SORT,
		payload: tenantSort
	}
}
export const ShowTenantSearchResult = (tenantSearchResult: boolean): ListsAction => {
	return {
		type: SET_SHOW_TENANT_SEARCH_STATUS,
		payload: tenantSearchResult
	}
}
export const SetUserPreferenceList = (userPreferenceList: UserPreferenceList): ListsAction => {
	return {
		type: SET_USERPREFERENCE_LIST,
		payload: userPreferenceList
	}
}
export const SetUserPage = (userPageIndex: number): ListsAction => {
	return {
		type: USER_PAGE_CHANGED,
		payload: userPageIndex
	}
}
export const SetUserPageSize = (userPageSize: number): ListsAction => {
	return {
		type: USER_PAGE_SIZE_CHANGED,
		payload: userPageSize
	}
}
export const SetUserTotalCount = (totalUserPeference: number): ListsAction => {
	return {
		type: USER_TOTAL_COUNT_CHANGED,
		payload: totalUserPeference
	}
}
export const SetChecked = (checked: boolean): ListsAction => {
	return {
		type: CHECKED,
		payload: checked
	}
}
export const SetPreferenceId = (preferenceId: string): ListsAction => {
	return {
		type: PREFERENCE_ID,
		payload: preferenceId
	}
}
export const SetUserSort = (userSort: string): ListsAction => {
	return {
		type: SET_USER_SORT,
		payload: userSort
	}
}
export const SetUserSearchResultStatus = (userSerachStatus: boolean): ListsAction => {
	return {
		type: SET_USER_SEARCH_RESULT_STATUS,
		payload: userSerachStatus
	}
}
export const SetSearchApplication = (searchApplication: string): ListsAction => {
	return {
		type: SET_SEARCH_APPLICATION_NAME,
		payload: searchApplication
	}
}
export const TenantLicenseId = (tenantLicenseId: string): ListsAction => {
	return {
		type: TENANT_LICENSE_ID,
		payload: tenantLicenseId
	}
}

export const SetSearchTenant = (searchTenant: string): ListsAction => {
	return {
		type: SET_SEARCH_TENANT,
		payload: searchTenant
	}
}

export const LicenseName = (licenseName: string): ListsAction => {
	return {
		type: LICENSE_NAME,
		payload: licenseName
	}
}
export const ProductVersion = (productVerison: string): ListsAction => {
	return {
		type: PRODUCT_VERSION,
		payload: productVerison
	}
}
export const BedDetails = (bedDetails: number): ListsAction => {
	return {
		type: BED_DETAILS,
		payload: bedDetails
	}
}
export const ActivationDate = (activationDate: number): ListsAction => {
	return {
		type: ACTIVATION_DATE,
		payload: activationDate
	}
}

export const SetLicenseData = (licenseList: LicenseList): ListsAction => {
	return {
		type: SET_LICENSE_DATA,
		payload: licenseList
	}
}

export const SetLicensePage = (page: number): ListsAction => {
	return {
		type: LICENSE_PAGE_CHANGED,
		payload: page

	}
}
export const SetLicensePageSize = (page: number): ListsAction => {
	return {
		type: LICENSE_PAGE_SIZE_CHANGED,
		payload: page
	}
}
export const SetLicenseTotalCount = (page: number): ListsAction => {
	return {
		type: LICENSE_TOTAL_COUNT_CHANGED,
		payload: page

	}
}

export const SetLicenseSorting = (sort: string): ListsAction => {
	return {
		type: SET_LICENSE_SORTING,
		payload: sort

	}
}

export const SetSearchLicenseName = (searchLicense: string): ListsAction => {
	return {
		type: SET_LICENSE_NAME,
		payload: searchLicense
	}
}

export const resetLicenseState = (): ListsAction => {
	return {
		type: RESET_LICENSCE_STATE,
	}
}

export const resetUserState = (): ListsAction => {
	return {
		type: RESET_USER_STATE,
	}
}
export const resetListState = (): ListsAction => {
	return {
		type: RESET_LIST_STATE,
	}
}
