/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import {
	GET_LIST, ListsAction, ListStates, SET_SEARCH_TENANT, SET_LIST, RESET_LICENSCE_STATE, RESET_LIST_STATE, RESET_USER_STATE, SET_TOGGLE_HISTORY_VIEW, PAGE_CHANGED, PAGE_SIZE_CHANGED, TOTAL_COUNT_CHANGED, SEARCH, SET_SORTING, SET_APPLICATION_LIST, SET_APPLICATION_NAME, SET_TENANT_CONNECTION_LIST, SET_DATEWISE_CLOUD_STATUS, TABLE_PAGE_CHANGED, TABLE_PAGE_SIZE_CHANGED, TABLE_TOTAL_COUNT_CHANGED, SET_TOGGLE_TENANT_HISTORY_VIEW, SET_TENANT_NAME_LIST, SET_TENANT_ID, SET_TENANT_DAYWISE_STATUS, SET_DOWN_TIME_STATUS, SET_DATE, TENANT_LICENSE_ID, LICENSE_NAME, PRODUCT_VERSION, BED_DETAILS, ACTIVATION_DATE, SET_SEARCH_APPLICATION_NAME, SET_USER_SEARCH_RESULT_STATUS, SET_USER_SORT, PREFERENCE_ID, CHECKED, USER_TOTAL_COUNT_CHANGED, USER_PAGE_SIZE_CHANGED, USER_PAGE_CHANGED, SET_USERPREFERENCE_LIST, SET_SEARCH_RESULT_STATUS, SET_TENANT_SORT, SET_SHOW_TENANT_SEARCH_STATUS, SET_LICENSE_SORTING, LICENSE_TOTAL_COUNT_CHANGED, LICENSE_PAGE_SIZE_CHANGED, LICENSE_PAGE_CHANGED, SET_LICENSE_DATA, UserPreferenceState, LicenseDetailsState, SET_LICENSE_NAME
} from "../types";

const initialState: ListStates = {
	lists: [],
	status: false,
	queryPageIndex: 0,
	queryPageSize: 5,
	totalCount: 0,
	isSearch: false,
	sort: 'asc',
	appList: [],
	selectedApplication: '',
	tenantList: [],
	dateWiseStatus: false,
	pageIndex: 0,
	pageSize: 5,
	totalTenant: 0,
	tenantStatus: false,
	tenantNameList: [],
	selectedTenant: '',
	showDaywiseStatus: false,
	showDownTimeStatus: false,
	selectedDate: '',
	displayStatus: true,
	tenantSort: 'asc',
	tenantSearchResult: true,
	searchApplication: '',
	searchTenant: ''
}
const userPreferenceInitialState: UserPreferenceState = {
	userPreferenceList: [],
	userPageIndex: 0,
	userPageSize: 10,
	totalUserPeference: 0,
	checked: false,
	preferenceId: '',
	userSort: 'asc',
	userSerachStatus: true
};
const licenseDetailsInitialState: LicenseDetailsState = {
	tenantLicenseId: '',
	licenseName: '',
	productVerison: '',
	bedDetails: 0,
	activationDate: 0,
	licensePageIndex: 0,
	totalLicense: 0,
	licenseSort: 'asc',
	licensePageSize: 10,
	licenseList: [],
	searchLicense: ''
};

export const listStates = (state = initialState, action: ListsAction): ListStates => {
	switch (action.type) {
		case SET_LIST:
			return {
				...state,
				lists: action.payload,

			}
		case GET_LIST:
			return {
				...state

			}
		case SET_TOGGLE_HISTORY_VIEW:
			return {
				...state,
				status: action.payload

			}
		case PAGE_CHANGED:
			return {
				...state,
				queryPageIndex: action.payload
			};
		case PAGE_SIZE_CHANGED:
			return {
				...state,
				queryPageSize: action.payload,
			};
		case TOTAL_COUNT_CHANGED:
			return {
				...state,
				totalCount: action.payload,
			};
		case SEARCH:
			return {
				...state,
				isSearch: action.payload

			}
		case SET_SORTING:
			return {
				...state,
				sort: action.payload,
			};
		case SET_APPLICATION_LIST:
			return {
				...state,
				appList: action.payload,

			}
		case SET_APPLICATION_NAME:
			return {
				...state,
				selectedApplication: action.payload,
			}

		case SET_TENANT_CONNECTION_LIST:
			return {
				...state,
				tenantList: action.payload,
			};
		case SET_DATEWISE_CLOUD_STATUS:
			return {
				...state,
				dateWiseStatus: action.payload,
			}
		case TABLE_PAGE_CHANGED:
			return {
				...state,
				pageIndex: action.payload
			};
		case TABLE_PAGE_SIZE_CHANGED:
			return {
				...state,
				pageSize: action.payload,
			};
		case TABLE_TOTAL_COUNT_CHANGED:
			return {
				...state,
				totalTenant: action.payload,
			};
		case SET_TOGGLE_TENANT_HISTORY_VIEW:
			return {
				...state,
				tenantStatus: action.payload

			};
		case SET_TENANT_NAME_LIST:
			return {
				...state,
				tenantNameList: action.payload
			};
		case SET_TENANT_ID:
			return {
				...state,
				selectedTenant: action.payload,
			};
		case SET_TENANT_DAYWISE_STATUS:
			return {
				...state,
				showDaywiseStatus: action.payload,
			};
		case SET_DOWN_TIME_STATUS:
			return {
				...state,
				showDownTimeStatus: action.payload,
			};
		case SET_DATE:
			return {
				...state,
				selectedDate: action.payload,
			};
		case SET_SEARCH_RESULT_STATUS:
			return {
				...state,
				displayStatus: action.payload,
			};
		case SET_TENANT_SORT:
			return {
				...state,
				tenantSort: action.payload
			};
		case SET_SHOW_TENANT_SEARCH_STATUS:
			return {
				...state,
				tenantSearchResult: action.payload,
			};
		case SET_SEARCH_APPLICATION_NAME:
			return {
				...state,
				searchApplication: action.payload,
			};
		case SET_SEARCH_TENANT:
			return {
				...state,
				searchTenant: action.payload,
			};
		case RESET_LIST_STATE:
			return initialState;
		default:
			return state;
	}
}
export const userPreferenceState = (state = userPreferenceInitialState, action: ListsAction): UserPreferenceState => {
	switch (action.type) {
		case SET_USERPREFERENCE_LIST:
			return {
				...state,
				userPreferenceList: action.payload
			};
		case USER_PAGE_CHANGED:
			return {
				...state,
				userPageIndex: action.payload
			};
		case USER_PAGE_SIZE_CHANGED:
			return {
				...state,
				userPageSize: action.payload
			};
		case USER_TOTAL_COUNT_CHANGED:
			return {
				...state,
				totalUserPeference: action.payload
			};
		case CHECKED:
			return {
				...state,
				checked: action.payload
			};
		case PREFERENCE_ID:
			return {
				...state,
				preferenceId: action.payload
			};
		case SET_USER_SORT:
			return {
				...state,
				userSort: action.payload
			};
		case SET_USER_SEARCH_RESULT_STATUS:
			return {
				...state,
				userSerachStatus: action.payload,
			};
		case RESET_USER_STATE:
			return userPreferenceInitialState;
		default:
			return state;
	}
}
export const licenseDetailsState = (state = licenseDetailsInitialState, action: ListsAction): LicenseDetailsState => {
	switch (action.type) {
		case TENANT_LICENSE_ID:
			return {
				...state,
				tenantLicenseId: action.payload,
			};
		case LICENSE_NAME:
			return {
				...state,
				licenseName: action.payload,
			};
		case PRODUCT_VERSION:
			return {
				...state,
				productVerison: action.payload,
			};
		case BED_DETAILS:
			return {
				...state,
				bedDetails: action.payload,
			};
		case ACTIVATION_DATE:
			return {
				...state,
				activationDate: action.payload,
			};
		case SET_LICENSE_DATA:
			return {
				...state,
				licenseList: action.payload,
			};
		case LICENSE_PAGE_CHANGED:
			return {
				...state,
				licensePageIndex: action.payload
			};
		case LICENSE_PAGE_SIZE_CHANGED:
			return {
				...state,
				licensePageSize: action.payload,
			};
		case LICENSE_TOTAL_COUNT_CHANGED:
			return {
				...state,
				totalLicense: action.payload,
			};
		case SET_LICENSE_SORTING:
			return {
				...state,
				licenseSort: action.payload,
			};
		case SET_LICENSE_NAME:
			return {
				...state,
				searchLicense: action.payload,
			};
		case RESET_LICENSCE_STATE:
			return licenseDetailsInitialState;
		default:
			return state;

	}
}