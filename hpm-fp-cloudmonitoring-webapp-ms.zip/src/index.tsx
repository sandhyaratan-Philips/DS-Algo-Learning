/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/

import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.scss';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { ThemeProvider } from 'styled-components';
import { Provider } from 'react-redux';
import store from './store/store';
import { GlobalStyle } from '@dls/react-globalstyle';
import { makeTheme } from '@dls/react-theme';
import { createTheme } from '@mui/material/styles';
import { BrowserRouter } from 'react-router-dom';

const defaultTheme = {
	color: 'group-blue',
	accent: 'pink',
	tone: 'ultra-light',
	density: 'regular',
};

const theme = createTheme({ ...makeTheme(defaultTheme as any)() } as any);

const container = document.getElementById('root');
const root = createRoot(container!);

root.render(
	<React.StrictMode>
		<Provider store={store}>
			<ThemeProvider theme={theme}>
				<GlobalStyle />
				<BrowserRouter basename="/monitoring">
					<App />
				</BrowserRouter>
			</ThemeProvider>
		</Provider>
	</React.StrictMode>
);


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

