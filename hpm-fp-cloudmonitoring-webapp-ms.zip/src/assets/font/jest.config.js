process.env.TZ = 'UTC';
const config = require('../../jest.config');

module.exports = {
  ...config,
};
