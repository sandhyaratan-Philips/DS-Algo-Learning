# Changelog

This file was generated using [@jscutlery/semver](https://github.com/jscutlery/semver).

## [9.16.0](https://github.com/philips-internal/dls-react/compare/v9.15.0...v9.16.0) (2023-03-01)

## [9.15.0](https://github.com/philips-internal/dls-react/compare/v9.14.0...v9.15.0) (2023-02-17)


### Features

* switch from Lerna to NX versioning and publishing ([#1206](https://github.com/philips-internal/dls-react/issues/1206)) ([476b38f](https://github.com/philips-internal/dls-react/commit/476b38fd62430a000e145a93c447d94ee25fae09))

## [9.14.0](https://github.com/philips-internal/dls-react/compare/v9.13.0...v9.14.0) (2023-02-16)


### Features

* switch from Lerna to NX versioning and publishing ([#1206](https://github.com/philips-internal/dls-react/issues/1206)) ([476b38f](https://github.com/philips-internal/dls-react/commit/476b38fd62430a000e145a93c447d94ee25fae09))

## [9.14.0](https://github.com/philips-internal/dls-react/compare/v9.13.0...v9.14.0) (2023-02-06)


### Features

* initial commit for nx versioning and publishing ([777f4c3](https://github.com/philips-internal/dls-react/commit/777f4c3349d9c8cef9fad7d3e9fbdac266b516dd))
* move to yarn v3 to use workspace ranges for publishing ([d8016f6](https://github.com/philips-internal/dls-react/commit/d8016f61df54843ca010fa8d6838b68ec1dac221))
* remove double syncVersion from project version:prerelease ([f88112e](https://github.com/philips-internal/dls-react/commit/f88112e57b046263c1072d42fdfbc7a10e8031ef))
* set trackdeps to false as we sync versions and post-update script for react-core deps ([29fb23e](https://github.com/philips-internal/dls-react/commit/29fb23e128e332ac89191e440b86c845d7290cb7))

# [9.13.0](https://github.com/philips-internal/dls-react/compare/v9.12.3...v9.13.0) (2023-01-18)


### Features

* 🎸 Remove all material-ui 4 dependencies from sample app ([#1185](https://github.com/philips-internal/dls-react/issues/1185)) ([189cfd8](https://github.com/philips-internal/dls-react/commit/189cfd83228656dd6b622f04fb560d18b0b61850))





## [9.12.2](https://github.com/philips-internal/dls-react/compare/v9.12.0...v9.12.2) (2023-01-13)

**Note:** Version bump only for package @dls/react-fonts





## [9.12.1](https://github.com/philips-internal/dls-react/compare/v9.12.0...v9.12.1) (2023-01-13)

**Note:** Version bump only for package @dls/react-fonts





## [9.4.1](https://github.com/philips-internal/dls-react/compare/v9.4.0...v9.4.1) (2022-09-13)

**Note:** Version bump only for package @dls/react-fonts





# [9.0.0](https://github.com/philips-internal/dls-react/compare/v8.5.1...v9.0.0) (2022-05-10)

**Note:** Version bump only for package @dls/react-fonts





# [8.0.0](https://github.com/philips-internal/dls-react/compare/v7.4.7...v8.0.0) (2022-01-19)

**Note:** Version bump only for package @dls/react-fonts





## [7.3.1](https://github.com/philips-internal/dls-react/compare/v7.3.0...v7.3.1) (2021-11-08)

**Note:** Version bump only for package @dls/react-fonts





## [7.2.3](https://github.com/philips-internal/dls-react/compare/v7.2.2...v7.2.3) (2021-09-22)

**Note:** Version bump only for package @dls/react-fonts





# [7.0.0](https://github.com/philips-internal/dls-react/compare/v6.0.2...v7.0.0) (2021-08-24)

**Note:** Version bump only for package @dls/react-fonts





# [6.0.0](https://github.com/philips-internal/dls-react/compare/v5.1.0...v6.0.0) (2021-07-08)

**Note:** Version bump only for package @dls/react-fonts





# [5.0.0](https://github.com/philips-internal/dls-react/compare/v4.0.0...v5.0.0) (2021-05-27)

**Note:** Version bump only for package @dls/react-fonts





# [4.0.0](https://github.com/philips-internal/dls-react/compare/v3.0.4...v4.0.0) (2021-05-27)

**Note:** Version bump only for package @dls/react-fonts





## [3.0.3](https://github.com/philips-internal/dls-react/compare/v3.0.2...v3.0.3) (2021-04-19)

**Note:** Version bump only for package @dls/react-fonts





# [3.0.0](https://github.com/philips-internal/dls-react/compare/v2.16.1...v3.0.0) (2021-02-05)

**Note:** Version bump only for package @dls/react-fonts





## [2.16.1](https://github.com/philips-internal/dls-react/compare/v2.16.0...v2.16.1) (2021-02-04)


### Bug Fixes

* update package dependencies ([781d3de](https://github.com/philips-internal/dls-react/commit/781d3decd64140f9964e47c751b965e56a6cd0eb))





# [2.0.0](https://github.com/philips-internal/dls-react/compare/v1.28.1...v2.0.0) (2020-09-29)

**Note:** Version bump only for package @dls/react-fonts





# 1.0.0 (2020-06-10)

**Note:** Version bump only for package @dls/react-fonts





# 1.0.0 (2020-06-10)

**Note:** Version bump only for package @dls/react-fonts
