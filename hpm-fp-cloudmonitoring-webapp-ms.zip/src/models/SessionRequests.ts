/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Harsha B A
 * Date:        08/04/2023 11:00:00 AM
 *
 **/

export interface LoginUserRequest {
	loginUserName: string;
	loginUserKey: string;
}
