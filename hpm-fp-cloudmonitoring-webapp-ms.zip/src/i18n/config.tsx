
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner. 
 * 
 * Author:      Harsha B A
 * Date:        29/03/2023 03:00:00 PM
 * 
 **/

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { environment } from '../environment/environment';

i18n.use(initReactI18next).init({
	fallbackLng: environment.language,
	lng: environment.language,
	resources: {
		en: {
			translations: require('./locales/en/translations.json')
		},
		de: {
			translations: require('./locales/de/translations.json')
		}
	},
	ns: ['translations'],
	defaultNS: 'translations'
});

i18n.languages = ['en', 'de'];

export default i18n;