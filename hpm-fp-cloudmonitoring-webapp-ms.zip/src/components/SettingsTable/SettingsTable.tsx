/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        22/05/2023 11:00:00 AM
 *
 **/

import React, { FC, useEffect } from 'react';
import { Checkbox } from '@dls/react-mui-checkbox';
import { Checkmark16 } from '@dls/react-icons';
import { Indeterminate16 } from '@dls/react-icons';
import { TableContainer } from '@dls/react-mui-table';
import { Table } from '@dls/react-mui-table';
import { TableHead } from '@dls/react-mui-table';
import { TableRow } from '@dls/react-mui-table';
import { TableBody } from '@dls/react-mui-table';
import { TableCell } from '@dls/react-mui-table';
import { Switch } from "@dls/react-mui-switch";
import { Button } from '@dls/react-mui-button';
import { Icon } from "@dls/react-icon";
import Alert from '@mui/material/Alert';
import IconButton from '@mui/material/IconButton';
import Collapse from '@mui/material/Collapse';
import CloseIcon from '@mui/icons-material/Close';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { getList, SetChecked, SetPreferenceId, SetUserPreferenceList, SetUserSort, SetUserTotalCount } from '../../store/actions/listActions';
import { useTranslation } from 'react-i18next';
import './SettingsTable.scss';
import { environment } from '../../environment/environment';
import * as  service from '../Services/Service';
import * as  constant from '../Common/util/util';
import { RootState } from '../../store/store';
import { useDispatch, useSelector } from 'react-redux';
import { Dialog, DialogContent, DialogContentText, DialogActions } from '@dls/react-mui-dialog';
import Tooltip from '@mui/material/Tooltip';

export default {
  title: 'Core/Table',
  component: Table,
};
const classes = constant.classes;

export const SettingsTable: FC<Record<string, unknown>> = () => {
  const dispatch = useDispatch();
  const [selected, setSelected] = React.useState<string[]>([]);
  const [errorMessage, setErrorMessage] = React.useState('');
  const [webChecked, setWebChecked] = React.useState(false);
  const [dataChecked, setDataChecked] = React.useState(false);
  const [fpChecked, setFpChecked] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const [openPopUp, setOpenPopUp] = React.useState(false);
  const [openErrorPopUp, setOpenErrorPopUp] = React.useState(false);
  const { t } = useTranslation('translations', { keyPrefix: 'userpreference' });
  const userSettingUrl = environment.BASE_URL + '/AlertSettings';

  const userPreferenceList = useSelector((state: RootState) => state.user.userPreferenceList);
  const checked = useSelector((state: RootState) => state.user.checked);
  const preferenceId = useSelector((state: RootState) => state.user.preferenceId);
  const userPageIndex = useSelector((state: RootState) => state.user.userPageIndex);
  const userPageSize = useSelector((state: RootState) => state.user.userPageSize);
  const userSort = useSelector((state: RootState) => state.user.userSort);
  const [showIcon, setShowIcon] = React.useState(false);
  const isSearch = useSelector((state: RootState) => state.list.isSearch);
  const [openConfirm, setOpenConfirm] = React.useState(false);
  const [variant, setVariant] = React.useState();
  const [item, setItem] = React.useState();
  const [touched, setTouched] = React.useState(false);

  useEffect(() => {
    getUserPrefference();
    setTouched(false);
  }, [userPageSize, userPageIndex, userSort]);

  const getUserPrefference = () => {
    const params: any = {
      pageNumber: userPageIndex + 1,
      recordsPerPage: userPageSize,
      sortingOrder: userSort,
    };
    if (!isSearch) {
      service.getUserPreferenceDetails(userSettingUrl, params).then((response: any) => {
        const resp: any = [];
        response.data.forEach((element: any) => {
          if (element.subscriptions === null) {
            element.subscriptions = [
              {
                applicationName: "hpm-fp-dataflow",
                subscribed: false
              },
              {
                applicationName: "focal-point-status",
                subscribed: false
              },
              {
                applicationName: "web-socket-client-connection",
                subscribed: false
              },
            ];
          }

          resp.push(element);
        });
        dispatch(SetUserTotalCount(response.data[0].totalRecords));
        if (response.data[0].subscriptions === null) {
          const cloudStatus: any = {
            preferenceId: null,
            tenantId: null,
            subscriptions: [
              {
                applicationName: "cloud-subscribed",
                subscribed: false
              }
            ]
          }
          dispatch(SetChecked(cloudStatus.subscriptions[0].subscribed));
          resp.push(cloudStatus);
        } else {
          response.data.forEach((element: any) => {
            element.subscriptions.forEach((dataItem: any) => {

              if (dataItem.applicationName === "cloud-subscribed") {
                dispatch(SetPreferenceId(element.preferenceId));
                dispatch(SetChecked(dataItem.subscribed));
              }
            })
          });

        }
        dispatch(SetUserPreferenceList(resp));
        dispatch(getList());
      }).catch(error => {
        setErrorMessage(error.errorMessage);
      });
    }
  }
  const sortlist = (eventName: string) => {
    if (eventName === "arrowDown") {
      setShowIcon(true);
    } else {
      setShowIcon(false);
    }
    dispatch(SetUserSort(eventName === 'arrowDown' ? 'desc' : 'asc'));
    getList();

  }
  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const newSelecteds = userPreferenceList.map((n: any) => n.tenantId);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event: React.MouseEvent<unknown>, tenantId: string) => {
    const selectedIndex = selected.indexOf(tenantId);
    let newSelected: string[] = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, tenantId);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      );
    }
    setSelected(newSelected);
  };

  const isSelected = (name: string) => selected.indexOf(name) !== -1;
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>, rowIndex: number, subIndex: number) => {
    const rows: any = [...userPreferenceList];
    (rows[rowIndex]).subscriptions[subIndex].subscribed = event.target.checked;
    dispatch(SetUserPreferenceList(rows));
  }

  const applySelection = () => {
    const finalList: any = [];
    selected.forEach((updateObject: string) => {
      const itemInList = userPreferenceList.filter((row: any) => row.tenantId == updateObject)[0];
      finalList.push(itemInList);
      setWebChecked(false);
      setDataChecked(false);
      setFpChecked(false);
    });
    const cloudStatus: any = {
      preferenceId: preferenceId !== null ? preferenceId : null,
      tenantId: null,
      subscriptions: [
        {
          applicationName: "cloud-subscribed",
          subscribed: checked
        }
      ]
    }
    finalList.push(cloudStatus);
    const editedItem: any = [];
    const newItem: any = [];
    finalList.forEach((element: any) => {
      if (element.preferenceId !== null) {
        editedItem.push(element);
      }
      else {
        newItem.push(element);
      }
    });
    if (editedItem.length !== 0) {
      service.editUserPreferenceDetails(userSettingUrl, editedItem).then((response) => {
        if (response.status === 200) {
          setOpenPopUp(true);
          setSelected([]);
        }
      }).catch((error) => {
        setErrorMessage(error.message);
        setOpenErrorPopUp(true);
        getList();
      });
    }
    if (newItem.length !== 0) {
      service.createUserPreference(userSettingUrl,
        newItem).then((response) => {
          if (response.status === 200) {
            setOpenPopUp(true);
            setSelected([]);
          }

        }).catch((error) => {
          setErrorMessage(error.message);
          setOpenErrorPopUp(true);
          getList();
        });
    }
    getUserPrefference();
    setTouched(false);
  }

  const closeErrorPopup = () => {
    setOpenErrorPopUp(false);
  }

  const bulkChangeSwitchweb = (event: React.ChangeEvent<HTMLInputElement>) => {
    setWebChecked(event.target.checked);
    const listSelected: any = [];
    selected.forEach((webObject: string) => {
      const webItemInList = userPreferenceList.filter((row: any) => row.tenantId == webObject)[0];
      listSelected.push(webItemInList);
    });
    switchToggle(listSelected, event);
  }

  const bulkChangeSwitchdata = (event: React.ChangeEvent<HTMLInputElement>) => {
    setDataChecked(event.target.checked);
    const dataListSelected: any = [];
    selected.forEach((dataObject: string) => {
      const dataItemInList = userPreferenceList.filter((row: any) => row.tenantId == dataObject)[0];
      dataListSelected.push(dataItemInList);
    });
    switchToggle(dataListSelected, event);

  }
  const bulkChangeSwitchfp = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFpChecked(event.target.checked);
    const fpListSelected: any = [];
    selected.forEach((fpObject: string) => {
      const fpItemInList = userPreferenceList.filter((row: any) => row.tenantId == fpObject)[0];
      fpListSelected.push(fpItemInList);
    });
    switchToggle(fpListSelected, event);
  }

  const switchToggle = (list: any, event: React.ChangeEvent<HTMLInputElement>) => {
    list.forEach((element: any) => {
      element.subscriptions.forEach((listElement: any) => {
        if (listElement.applicationName === event.target.name) {
          listElement.subscribed = event.target.checked;
        }
      });
    });
  }

  const handleClickMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const closePopup = () => {
    setOpenPopUp(false);
  };

  const resetSelections = () => {
    handleClickOpen('signal', 'Error');
  }
  const handleClickOpen = (variantValue: any, element: any) => {
    setOpenConfirm(true);
    setVariant(variantValue);
    setItem(element);
  };

  const handleCloudStatusChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTouched(true);
    dispatch(SetChecked(event.target.checked));

  }
  const handleClosepopup = () => {
    setOpenConfirm(false);

  };
  const confirmCancel = () => {
    getUserPrefference();
    setSelected([]);
    handleClosepopup();
  }
  return (
    <div>
      <div>
        <Dialog
          open={openConfirm}
          onClose={handleClosepopup}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description">
          <DialogContent>
            <DialogContentText
              id="alert-dialog-description"
              dls_variant={variant}
              dls_item={item}>
              <Icon name="Warning" className="contentIcon" />
              Are you sure you want to Cancel the selection which will reset your changes?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClosepopup} dls_variant="quietDefault">
              Cancel
            </Button>
            <Button onClick={confirmCancel} dls_variant="primary">
              OK
            </Button>
          </DialogActions>
        </Dialog>
      </div>
      <div style={{ float: 'left', marginBottom: "5px", marginLeft: "39px" }}>
        <span className="table-style">Subscribe to cloud status</span>
        <Switch color="secondary" checked={checked} onChange={(event: any) => handleCloudStatusChange(event)} style={{ float: "right" }} />
      </div>
      <div style={{ float: 'right', marginBottom: "5px", marginRight: "20px" }}>
        <div>
          {selected.length === 0 ?
            <Button
              id="basic-button" disabled
              dls_variant="secondary"
              aria-controls={open ? 'basic-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              onClick={handleClickMenu}
              style={{ marginLeft: "10px", width: "230px" }}
              className="table-style"
            >
              {t('LABEL_BULK_SUBSCRIBE')}
              <Icon
                name={"ArrowDown"}
                className={"ArrowDown-icon"}
                style={{ color: "white" }}
                size={"l"}
              />
            </Button> : <Button
              id="basic-button"
              dls_variant="primary"
              aria-controls={open ? 'basic-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              onClick={handleClickMenu}
              style={{ marginLeft: "10px", width: "230px" }}
              className="table-style"
            >
              {t('LABEL_BULK_SUBSCRIBE')}
              <Icon
                name={"ArrowDown"}
                className={"ArrowDown-icon"}
                style={{ color: "white" }}
                size={"l"}
              />
            </Button>}
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
            <MenuItem className="menuItem"><div style={{ marginRight: "37px" }}>{t('HEADING_WEBSOCKET_CLIENT')}</div><Switch color="secondary" checked={webChecked} name="web-socket-client-connection" onChange={(event: any) => bulkChangeSwitchweb(event)} /></MenuItem>
            <MenuItem className="menuItem"><div style={{ marginRight: "2px" }}>{t('HEADING_DATAFLOW')}</div><Switch color="secondary" checked={dataChecked} name="hpm-fp-dataflow" style={{ float: "right" }} onChange={(event: any) => bulkChangeSwitchdata(event)} /></MenuItem>
            <MenuItem className="menuItem"><div style={{ marginRight: "32px" }}>{t('HEADING_FOCAL_POINT_STATUS')}</div><Switch color="secondary" checked={fpChecked} name="focal-point-status" style={{ float: "right" }} onChange={(event: any) => bulkChangeSwitchfp(event)} /></MenuItem>
          </Menu>
        </div>
      </div>
      <div>
        {openPopUp && <Collapse in={openPopUp} className="alertPopup">
          <Alert
            action={
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => closePopup()}
              >
                <CloseIcon fontSize="inherit" />
              </IconButton>
            }
            sx={{ mb: 2 }}
          >
            {t('MESSAGE_SAVED')}
          </Alert>
        </Collapse>
        }
      </div>

      <div>
        {openErrorPopUp && <Collapse in={openErrorPopUp} style={{ margin: "0px 19px" }}>
          <Alert severity="error"
            action={
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => closeErrorPopup()}
              >
                <CloseIcon fontSize="inherit" />
              </IconButton>
            }
            sx={{ mb: 2 }}
          >
            {t('MESSAGE_FAILED')} {errorMessage} !
          </Alert>
        </Collapse>
        }
      </div>
      {userPreferenceList.length > 0 &&
        <TableContainer>
          <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    checkedIcon={
                      userPreferenceList.length > 0 &&
                        selected.length === userPreferenceList.length ? (
                        <Checkmark16 />
                      ) : (
                        <Indeterminate16 />
                      )
                    }
                    onChange={handleSelectAllClick}
                    checked={
                      userPreferenceList.length > 0 &&
                        selected.length === userPreferenceList.length
                        ? true
                        : false
                    }
                    className={classes.checkbox}
                  />
                </TableCell>
                <TableCell style={{ color: "#212121", marginRight: "4px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px" }}>{t('HEADING_TENANT_NAME')}
                  <IconButton className="icon-btn" onClick={() => sortlist(showIcon ? 'arrowUp' : 'arrowDown')}>
                    {showIcon ? (
                      <Icon
                        name={"ArrowUp"}
                        className={"ArrowDown-icon"}
                        size={"l"}
                      />
                    ) : (
                      <Icon
                        name={"ArrowDown"}
                        className={"ArrowDown-icon"}
                        size={"l"}
                        style={{ color: 'grey' }}
                      />
                    )}
                  </IconButton></TableCell>
                <TableCell style={{ color: "#212121", marginRight: "4px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px" }}>{t('HEADING_WEBSOCKET_CLIENT')}</TableCell>
                <TableCell style={{ color: "#212121", marginRight: "4px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px" }}>{t('HEADING_DATAFLOW')}</TableCell>
                <TableCell style={{ color: "#212121", marginRight: "4px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px" }}>{t('HEADING_FOCAL_POINT_STATUS')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {userPreferenceList.map((row: any, index) => {

                const isItemSelected = isSelected(row.tenantId);
                const labelId = `enhanced-table-checkbox-${index}`;
                if (row.subscriptions[0].applicationName !== 'cloud-subscribed') {
                  return (
                    <TableRow
                      key={row.tenantId}
                      role="checkbox"
                      aria-checked={isItemSelected}
                      tabIndex={-1}
                      selected={isItemSelected}>
                      <TableCell padding="checkbox">
                        <Checkbox
                          checkedIcon={<Checkmark16 />}
                          onChange={(event: any) => handleClick(event, row.tenantId)}
                          inputProps={{ 'aria-labelledby': labelId }}
                          checked={isItemSelected}
                          className={classes.checkbox}
                        />
                      </TableCell>
                      <TableCell scope="row"><Tooltip title={row.tenantName}><span>{row.tenantName.length > 32 ? row.tenantName.slice(0, 32) + "..." : row.tenantName}</span></Tooltip></TableCell>
                      <TableCell><Switch color="secondary" checked={row.subscriptions[2].subscribed} onChange={(event) => handleChange(event, index, 2)} style={{ float: "right" }} /></TableCell>
                      <TableCell><Switch color="secondary" checked={row.subscriptions[0].subscribed} onChange={(event) => handleChange(event, index, 0)} style={{ float: "right" }} /></TableCell>
                      <TableCell><Switch color="secondary" checked={row.subscriptions[1].subscribed} onChange={(event) => handleChange(event, index, 1)} style={{ float: "right" }} /></TableCell>
                    </TableRow>
                  )
                }
              })}
            </TableBody>
          </Table>
        </TableContainer>
      }
      <div className="controls">
        {selected.length === 0 && !touched ? <Button dls_variant="secondary" disabled style={{ marginRight: "6px" }}>{t('LABEL_CANCEL')}</Button> : <Button dls_variant="primary" onClick={resetSelections} style={{ marginRight: "6px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px" }}>{t('LABEL_CANCEL')}</Button>}
        {selected.length === 0 && !touched ? <Button dls_variant="secondary" disabled style={{ marginRight: "5px", float: 'right' }}>{t('LABEL_APPLY')}</Button> : <Button dls_variant="primary" style={{ marginRight: "5px", float: 'right', fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px" }} onClick={applySelection}>{t('LABEL_APPLY')}</Button>}
      </div>
    </div>
  );
};