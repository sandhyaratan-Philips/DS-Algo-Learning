/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        24/05/2023 11:00:00 AM
 *
 **/
import { SettingsTable } from "./SettingsTable";
import Enzyme, { ShallowWrapper } from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';

Enzyme.configure({ adapter: new Adapter() });
describe("SettingsTable component to be present in ui", () => {
    const mockDispatch = jest.fn();

    jest.mock('react-redux', () => ({
        useSelector: jest.fn(),
        useDispatch: () => mockDispatch
    }));
    jest.mock('react-i18next', () => ({
        ...jest.requireActual('react-i18next'),
        useTranslation: () => {
            return {
                t: (str: string) => str,
                i18n: {
                    language: 'en'
                },
            };
        },
    }));

    it("SettingsTable component to be in the document", () => {
        const settingTableComponent = new ShallowWrapper(<SettingsTable />);
        const settingTable = settingTableComponent.find('div');
        expect(settingTable).toBeTruthy();
    });
    it("Button component to be in the document", () => {
        const settingTableComponent = new ShallowWrapper(<SettingsTable />);
        const Button = settingTableComponent.find('Button');
        expect(Button).toBeTruthy();
    });

});

