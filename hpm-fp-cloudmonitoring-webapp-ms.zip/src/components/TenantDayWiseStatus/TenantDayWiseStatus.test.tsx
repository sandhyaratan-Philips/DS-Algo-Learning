/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        07/03/2023 11:08:00 AM
 *
 **/
import { screen, render, fireEvent, act } from '@testing-library/react';
import { Provider } from 'react-redux';
import TenantDayWiseStatus from './TenantDayWiseStatus';
import store from "../../store/store";
import axios from 'axios';
import response from '../../mock/cloudApplicationListResponse.json';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;
describe('TenantDayWiseStatus component', () => {
  const tenantName = "hpmtenat";
  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));

  it("Render TenantDayWiseStatus component", () => {
    renderWithContext(<TenantDayWiseStatus props={tenantName} />);
  });

  it("loading the main layout of card to be present", () => {
    renderWithContext(<TenantDayWiseStatus props={tenantName} />);
    const loading = screen.getByTestId("loading");
    expect(loading).toBeInTheDocument();
  });

  it("Render TenantDayWiseStatus component", () => {
    renderWithContext(<TenantDayWiseStatus props={tenantName} />);
    setTimeout(() => {
      const bargraph = screen.getByTestId("tenant-bargraph");
      expect(bargraph).toBeInTheDocument();
    }, 5000);
  });
  it("Render tenant-list in TenantDayWiseStatus component", () => {
    renderWithContext(<TenantDayWiseStatus props={tenantName} />);
    setTimeout(() => {
      const tenantList = screen.getByTestId("tenant-list");
      expect(tenantList).toBeInTheDocument();
    }, 5000);
  });

  it("Render statusBar in TenantDayWiseStatus component", () => {
    renderWithContext(<TenantDayWiseStatus props={tenantName} />);
    setTimeout(() => {

      const statusBar = screen.getByTestId("status-bar");

      expect(statusBar).toBeInTheDocument();
      act(() => {
        fireEvent.click(statusBar);
      });
      const mockedResponse: any = {
        data: response,
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},

      };
      mockedAxios.get.mockResolvedValue(mockedResponse);
      renderWithContext(<TenantDayWiseStatus />);
      expect(axios.get).toBeCalledTimes(1);
    }, 5000);
  });

  it('renders response from api response', () => {
    renderWithContext(<TenantDayWiseStatus />);
    const mockedResponse: any = {
      data: response,
      status: 200,
      statusText: 'OK',
      headers: {},
      config: {},

    };
    mockedAxios.get.mockResolvedValue(mockedResponse);
    renderWithContext(<TenantDayWiseStatus />);
    expect(axios.get).toHaveBeenCalled();
  });
  function renderWithContext(element: React.ReactElement) {
    render(
      <Provider store={store}>{element}</Provider>
    )
  }
});


