/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        02/03/2023 12:00:00 PM
 *
 **/

import axios from "axios";
import { useEffect, useState } from "react";
import "./TenantDayWiseStatus.scss";
import { environment } from "../../environment/environment";
import Spinner from "react-bootstrap/Spinner";
import Alert from "react-bootstrap/Alert";
import { ApplicationInfo, StatusInfo } from "../../store/types";
import CustomWidthTooltip from "@mui/material/Tooltip";
import { Col, Row } from "react-bootstrap";
import { Dialog, DialogTitle, DialogContent, DialogContentText } from '@dls/react-mui-dialog';
import { Typography } from '@dls/react-mui-typography';
import { Icon } from '@dls/react-icon';
import Table from 'react-bootstrap/Table';
import { LABEL } from "../Common/constants";
import * as  formateDate from '../Common/util/util';
import { SetDownTimeStatus } from "../../store/actions/listActions";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store/store";
import DownTimeStatus from "../DownTimeStatus/DownTimeStatus";


const TenantDayWiseStatus = (props: any) => {
	const dispatch = useDispatch();
	const [loadingData, setLoadingData] = useState(true);
	const [errorDetailMessage, setErrorDetailMessage] = useState('');
	const [tenantApplicationList, setTenantApplicationList] = useState([]);
	const [hourlyPopupOpen, setHourlyPopupOpen] = useState(false);
	const [displayName, setDisplayName] = useState('');
	const [startingTime, setStartingTime] = useState('');
	const [endingTime, setEndingTime] = useState('');
	const [downStatustime, setDownStatusTime] = useState([{}]);
	const TENANT_CONNECTION_STATUS_URL = environment.BASE_URL + '/HealthCheck';
	const TENANT_HOURLY_STATUS_URL = environment.BASE_URL + '/HealthCheck/hourly';
	const showDownTimeStatus = useSelector((state: RootState) => state.list.showDownTimeStatus);
	const selectedDate = useSelector((state: RootState) => state.list.selectedDate);

	useEffect(() => {
		if (props.isCalender) {
			getDaywiseStatus(props.tenantId);
		} else {
			getApplicationList(props.tenantId);
		}

	}, []);

	const getApplicationList = async (tenantId: string) => {
		const date: Date = new Date();
		const today = date.toISOString().split('.')[0] + "Z";
		const yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).toISOString().split('.')[0] + "Z";

		try {
			const response = await axios.get(TENANT_CONNECTION_STATUS_URL, {
				params: {
					daywiseStatus: true,
					start: yesterday,
					end: today,
					pageNumber: 1,
					recordsPerPage: 5,
					applicationName: '',
					sortingOrder: 'asc',
					tenantId: tenantId
				}, headers: {
					Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
				}
			});
			setTenantApplicationList(response.data);
		} catch (error) {
			setErrorDetailMessage("Data is null");
		}
		finally {
			setLoadingData(false);
		}
	}
	const getDaywiseStatus = async (tenantId: string) => {
		const selectedDateCalendar = selectedDate.split('.')[0] + "Z";
		try {
			const response = await axios.get(TENANT_CONNECTION_STATUS_URL, {
				params: {
					daywiseStatus: true,
					start: formateDate.getStartDate(selectedDateCalendar),
					end: formateDate.getEndDate(selectedDateCalendar),
					pageNumber: 1,
					recordsPerPage: 5,
					applicationName: '',
					sortingOrder: 'asc',
					tenantId: tenantId
				}, headers: {
					Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
				}
			});
			setTenantApplicationList(response.data);
		} catch (error) {
			setErrorDetailMessage("Data is null");
		}
		finally {
			setLoadingData(false);
		}
	}

	const handleOpenStatus = (appInfo: ApplicationInfo, statusItem: StatusInfo) => {
		if (statusItem.status === 'NORECORDS') {
			dispatch(SetDownTimeStatus(false));
		} else {
			if (props.isCalender) {
				dispatch(SetDownTimeStatus(true));
			}
			getHourDetail(statusItem.date);
			setDisplayName(appInfo.displayName);
			const endtime = formateDate.getEndTimeValue(statusItem);
			if (statusItem.status !== "NORECORDS") {
				axios.get(TENANT_HOURLY_STATUS_URL, {
					params: {
						applicationName: appInfo.applicationName,
						start: statusItem.date + 'Z',
						end: endtime + 'Z',
						tenantId: props.tenantId
					}, headers: {
						Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
					}
				}).then((response) => {
					setDownStatusTime(response.data.status);
				}).catch(error => {
					setErrorDetailMessage(error.errorCode);
				});
				setTimeout(() => {
					setHourlyPopupOpen(true);
				}, 1000);

			}
		}

	};
	const getHourDetail = (localTime: string) => {
		const localDate = new Date(localTime);
		setStartingTime(localDate.getHours().toString());
		setEndingTime((localDate.getHours() + 1).toString());
	}

	const handlePopUpClose = () => {
		setHourlyPopupOpen(false);
	};
	if (loadingData)
		return (
			<div className="spinner-style" data-testid="loading">
				<Spinner animation="border" variant="dark" />
			</div>
		);
	if (errorDetailMessage)
		return (
			<div data-testid="titleTenant">
				<Alert>{errorDetailMessage}</Alert>
			</div>
		);
	return (
		<div className="bar-graph" data-testid="tenant-bargraph">
			{tenantApplicationList && tenantApplicationList.map((applicationInfo: ApplicationInfo,parentindex: number) => {
				return (
					<Row key={`${parentindex}_tenantDaywise`}>
						<Col md={3}>
							<div className="appName">{applicationInfo.displayName}</div>
						</Col>
						<Col md={9}>
							<div className="bar-list statusChart" data-testid="tenant-list">
								{applicationInfo.status.length === 0 ? <div>{LABEL.LABEL_NO_STATUS}</div> : applicationInfo.status.map((statusItem: StatusInfo,index: number) => {
									return (
										<CustomWidthTooltip key={`${index}_CustomWidthTooltip_${parentindex}`} title={statusItem.status + "\n" + statusItem.date}
											placement="bottom" arrow>
											<div className={statusItem.status} data-testid="status-bar" onClick={() => {
												handleOpenStatus(applicationInfo, statusItem)
											}}>
											</div>
										</CustomWidthTooltip >
									)
								})}
							</div>
						</Col>
					</Row>
				)
			})}
			<span className="discalimer"> {LABEL.LABEL_DISCLAIMER}</span>
			{showDownTimeStatus && props.isCalender && displayName.length !== 0 ?
				<div className="tenantdatewise-style">
					<div style={{ paddingTop: "5px", paddingRight: "7px" }}>
						<span className="application-name heading"><span>{LABEL.LABEL_HOUR_CONNECTION_DETAILS}</span>{displayName}</span>
						<div className="downTime-style">
							{downStatustime.length === 0 ? <div className="table-datastyle"> <p className="table-datastyle">{LABEL.LABEL_NO_DOWN_TIME} :<b>{startingTime}:00:00 to {endingTime}:00:00</b> </p>Application is up and running</div> :
								<div style={{ marginLeft: "10px" }}>
									{displayName ? <div className="table-datastyle">{LABEL.LABEL_DOWN_TIME_DETAILS}<span><b> {startingTime}:00:00 to {endingTime}:00:00</b>  </span></div> :
										<div className="table-datastyle">{LABEL.LABEL_DOWN_TIME_DETAILS}</div>}
									{errorDetailMessage.length !== 0 ? <div>{errorDetailMessage}</div> :
										<Table hover style={{ width: "923px" }}>
											<thead>
												<tr>
													<th>{LABEL.FROM}</th>
													<th>{LABEL.TO}</th>
													<th>{LABEL.DURATION}</th>
												</tr>
											</thead>
											<tbody>
												{displayName && downStatustime.map((statusArray: any) => {
													return (
														<tr className="table-datastyle" key={statusArray.from}>
															<td>{statusArray.from}</td>
															<td>{statusArray.to ? statusArray.to : <span style={{ color: "red" }}>Actively Down</span>}</td>
															<td>{statusArray.duration ? statusArray.duration : <span style={{ color: "red" }}></span>}</td>
														</tr>
													)
												})
												}
											</tbody>
										</Table>
									}
								</div>
							}
						</div>
					</div>
				</div> :
				<div>
					<Dialog
						open={hourlyPopupOpen}
						onClose={handlePopUpClose}
						hideBackdrop
						aria-labelledby="dialog-title"
						aria-describedby="dialog-description">
						<DialogTitle id="dialog-title">
							<Typography className="application-name">{displayName}</Typography>
							<Icon
								name="Cross"
								size="m"
								className={'dlsIcon header'}
								onClick={handlePopUpClose}
							/>
						</DialogTitle>
						<DialogContent>
							<DialogContentText id="dialog-description">
								<Typography variant="body2">
									{downStatustime.length === 0 ? <div className="table-datastyle"> <p className="table-datastyle">{LABEL.LABEL_NO_DOWN_TIME} :<b>{startingTime}:00:00 to {endingTime}:00:00</b> </p>Application is up and running</div> :
										<div>
											<p className="table-datastyle">{LABEL.LABEL_DOWN_TIME_DETAILS}: <b> {startingTime}:00:00 to {endingTime}:00:00</b> </p>
											{errorDetailMessage.length !== 0 ? <div>{errorDetailMessage}</div> :
												<DownTimeStatus dispalyName={displayName} downStatustime={downStatustime} ></DownTimeStatus>
											}
										</div>
									}
								</Typography>
							</DialogContentText>
						</DialogContent>
					</Dialog>
				</div>
			}

		</div>
	)
}
export default TenantDayWiseStatus;