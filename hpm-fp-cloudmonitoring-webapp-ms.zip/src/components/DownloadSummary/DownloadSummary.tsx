/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      divyashree
 * Date:        17/08/2023 10:00:00 AM
 *
 **/

import React, { useState } from "react";
import { Icon } from "@dls/react-icon";
import { Button } from "@dls/react-core";
import { environment } from "../../environment/environment";
import * as  service from '../Services/Service';
import { LABEL } from "../Common/constants";
import "./DownloadSummary.scss";

export default function DownloadSummary() {
    const LICENSE_EXPORT_URL = environment.BASE_URL + "/InstallBase/Export";
    const [message, setMessage] = useState("");
    const [showMessage, setShowMessage] = useState(false);

    function downloadData() {
        service.exportLicenseList(LICENSE_EXPORT_URL, {}).then((response: any) => {
            if (response.status === 200) {
                const blob = new Blob([response.data], { type: 'application/octet-stream' });
                const downloadLink = document.createElement('a');
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = 'Install-Base.csv';
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            }
        }).catch(() => {
            setMessage(LABEL.UNABLE_TO_DOWNLOAD_THE_REPORT_PLEASE_TRY_AFTER_SOMETIME);
            setShowMessage(true);
        });
    }

    function closeMessage() {
        setShowMessage(false);
    }
    return (
        <div>
            <Button onClick={downloadData} dls_variant="primary" style={{ marginTop: "17px", float: 'right', borderRadius: '0px', border: '0', marginRight: "-50px", padding: '1rem', whiteSpace: 'nowrap', color: "#BFE2EB" }} >
                <Icon name="DocumentDownload32" size={"l"} />
                {LABEL.DOWNLOAD_SUMMARY}
            </Button>
            {
                showMessage && (
                    <div data-bs-placement="bottom">
                        <div style={{ display: "flex" }}>
                            <Icon name="ExclamationMarkCircle" size={"s"} style={{ marginRight: "10px", color: "red", marginTop: "211px", marginLeft: "804px", position: "fixed", top: "4px", left: "1px", width: "30%" }} />
                            <span className="Crossicon"> {message}</span>
                            <button type="button" className="closebutton" aria-label="close" onClick={closeMessage}>
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                )
            }
        </div>
    );
}
