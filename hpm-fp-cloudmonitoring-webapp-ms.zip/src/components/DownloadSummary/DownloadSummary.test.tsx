/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      DivyaShree U M
 * Date:        15/08/2023 11:00:00 AM
 *
 **/

import React from 'react';
import { ShallowWrapper } from 'enzyme';
import DownloadSummary from './DownloadSummary';

jest.mock('../Services/Service', () => ({
    exportLicenseList: jest.fn(() =>
        Promise.resolve({ status: 200, data: 'license data' })
    ),
}));

describe('DownloadSummary Component', () => {
    it('calls downloadData function and triggers download', async () => {
        const createObjectURLMock = jest.spyOn(URL, 'createObjectURL');
        createObjectURLMock.mockReturnValue('baseurl');
        expect(createObjectURLMock).toHaveBeenCalled();
        createObjectURLMock.mockRestore();
    });
    it("DownloadSummary component to be in the document", () => {
        const DownloadSummaryComponent = new ShallowWrapper(<DownloadSummary />);
        const set = DownloadSummaryComponent.find('div');
        expect(set).toBeTruthy();
    });
    it("Container component to be in the document", () => {
        const DownloadSummaryComponent = new ShallowWrapper(<DownloadSummary />);
        const container = DownloadSummaryComponent.find('Container');
        expect(container).toBeTruthy();

    });
    it("Card component to be in the document", () => {
        const DownloadSummaryComponent = new ShallowWrapper(<DownloadSummary />);
        const card = DownloadSummaryComponent.find('Card');
        expect(card).toBeTruthy();

    });
    it("Row component to be in the document", () => {
        const DownloadSummaryComponent = new ShallowWrapper(<DownloadSummary />);
        const row = DownloadSummaryComponent.find('Row');
        expect(row).toBeTruthy();

    });
    it("Col component to be in the document", () => {
        const DownloadSummaryComponent = new ShallowWrapper(<DownloadSummary />);
        const col = DownloadSummaryComponent.find('Col');
        expect(col).toBeTruthy();

    });
});

