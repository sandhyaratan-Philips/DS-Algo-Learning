/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { environment } from "../../environment/environment";
import { RootState } from "../../store/store";
import "./Calendar.scss";
import React, { useCallback } from "react";
import Spinner from "react-bootstrap/Spinner";
import Alert from "react-bootstrap/Alert";
import { SetDate, SetDatewiseStatus, setList, SetTenantDaywiseStatus } from "../../store/actions";
import DateWiseStatus from "../DateWiseStatus/DateWiseStatus";
import moment from "moment";
import { Dialog, DialogTitle, DialogContent, DialogContentText } from '@dls/react-mui-dialog';
import { Typography } from '@dls/react-mui-typography';
import { Icon } from '@dls/react-icon';
import TenantDayWiseStatus from "../TenantDayWiseStatus/TenantDayWiseStatus";
import * as  formateDate from '../Common/util/util';
import { LABEL } from "../Common/constants";


interface DisplayDays {
	day?: number,
	status?: string,
	formattedDate?: string
}

interface DisplayMonth {
	monthName?: string,
	days?: DisplayDays[]

}

export default function Calendar(props: any) {
	const dispatch = useDispatch();
	const [loading, setLoading] = useState(true);
	const [loadingBar, setLoadingBar] = useState(true);
	const [errorMessage, setErrorMessage] = useState('');
	const [displayDate, setDisplayDate] = useState('');
	const pageSize = useSelector((state: RootState) => state.list.queryPageSize);
	const applicationName = useSelector((state: RootState) => state.list.selectedApplication);
	const datewiseStatus = useSelector((state: RootState) => state.list.dateWiseStatus);
	const CLOUD_HEALTH_STATUS_URL = environment.BASE_URL + '/HealthCheck';
	const [dateArray, setDateArray] = useState([]);
	const tenantStatus = useSelector((state: RootState) => state.list.tenantStatus);
	const selectedTenant = useSelector((state: RootState) => state.list.selectedTenant);
	const showDaywiseStatus = useSelector((state: RootState) => state.list.showDaywiseStatus);
	const TENANT_HISTORY_URL = environment.BASE_URL + '/HealthCheck';
	const [popupOpen, setPopupOpen] = useState(false);

	useEffect(() => {
		getData();
	}, [applicationName, selectedTenant]);

	const getData = useCallback(async () => {
		const todayDate = new Date();
		const endDateD = todayDate.toISOString().split('.')[0] + "Z";
		const startDateValue = new Date(Date.UTC(todayDate.getFullYear(), todayDate.getMonth() -2, 1));
		const startDate = startDateValue.toISOString().split('.')[0] + "Z";
		let response: any = [];
		try {
			if (tenantStatus && props.card === 'tenant' && selectedTenant.length !== 0) {
				response = await axios.get(TENANT_HISTORY_URL,
					{
						params: {
							daywiseStatus: false,
							start: startDate,
							end: endDateD,
							pageNumber: 1,
							recordsPerPage: pageSize,
							applicationName: '',
							sortingOrder: 'asc',
							tenantId: selectedTenant
						}, headers: {
							Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
						}
					});
			} else {
				response = await axios.get(CLOUD_HEALTH_STATUS_URL,
					{
						params: {
							daywiseStatus: false,
							start: startDate,
							end: endDateD,
							pageNumber: 1,
							recordsPerPage: pageSize,
							applicationName: applicationName,
							sortingOrder: 'asc'
						}, headers: {
							Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
						}
					});
			}
			let data: any = [];
			const dateArrayValue: any = [];
			data = response.data;
			const currentDate = moment();
			const calculatedDate = new Date();
			calculatedDate.setDate(calculatedDate.getDate() - 91);
			const endDate = moment().subtract(91, "day");
			const monthsCount = Math.round(
				moment(currentDate).diff(endDate, "months", true)
			);

			[...Array(monthsCount)].forEach(() => {
				const dateMonth: DisplayMonth = {};
				dateMonth.monthName = currentDate.format("MMMM");
				const days = currentDate.daysInMonth();
				const daysArray: DisplayDays[] = [];
				[...Array(Array(days).length)].forEach((day, dayindex) => {
					const localDate = new Date(currentDate.toDate());
					localDate.setDate(dayindex + 1);
					const findInData =
						(data &&
							data[0] &&
							data[0].status.filter((obj: { date: string | number | Date }) => {
								const date = new Date(obj.date);
								return (
									date.toLocaleDateString() === localDate.toLocaleDateString()
								);
							})) ||
						[];
					const dayValue: DisplayDays = { day: dayindex + 1 };
					dayValue.status = findInData.length > 0 ? findInData[0].status : "";
					const dateFormat = currentDate.toDate();
					dateFormat.setDate(dayindex + 2);
					dayValue.formattedDate = dateFormat.toISOString();
					daysArray.push(dayValue);
					return null;
				});
				dateMonth["days"] = daysArray;
				currentDate.set("month", currentDate.month() - 1);
				dateArrayValue.push(dateMonth);
				return null;
			});

			setDateArray(dateArrayValue.reverse());
		}
		catch (error) {
			setErrorMessage("No data available");
		} finally {
			setLoading(false);
		}
	}, [dateArray, applicationName, selectedTenant]);

	const handleOpenbargraph = async (dateFormat: any) => {
		dispatch(SetDatewiseStatus(true));
		setLoadingBar(true);
		const selectedDateCalendar = dateFormat.split('.')[0] + "Z";
		try {
			const response = await axios.get(CLOUD_HEALTH_STATUS_URL, {
				params: {
					daywiseStatus: true,
					start: formateDate.getStartDate(selectedDateCalendar),
					end: formateDate.getEndDate(selectedDateCalendar),
					pageNumber: 1,
					recordsPerPage: 1,
					applicationName: applicationName,
					sortingOrder: 'asc'
				}, headers: {
					Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
				}
			});
			dispatch(setList(response.data));

		} catch (error) {
			setErrorMessage("Data is null");
		} finally {
			setLoadingBar(false);
		}
		setDisplayDate(dateFormat);
	}
	const handlePopUpClose = () => {
		setPopupOpen(false);
	};
	const setShowHourwiseStatus = (dateFormat: any) => {

		dispatch(SetDate(dateFormat));
		dispatch(SetTenantDaywiseStatus(true));
		setDisplayDate(dateFormat);
		setPopupOpen(true);
	}

	if (loading)
		return (
			<div className="spinner-style" data-testid="loading">
				<Spinner animation="border" variant="dark" />
			</div>
		);
	if (errorMessage)
		return (
			<div data-testid="titleTenant" style={{ marginTop: "53px" }}>
				<Alert>{errorMessage}</Alert>
			</div>
		);

	return (
		<div>
			<div className="calendar">
				{dateArray.map((dateObj: DisplayMonth, parentindex) => {
					return (
						<div key={`${parentindex}_calendar`}>
							<div className="monthName">{dateObj.monthName}</div>
							{dateObj.days &&
								dateObj.days.map((day: any, index: number) => {
									return (
										<span
											className={day.status && day.status.toLowerCase()}
											key={`${index}_calendaritem_${parentindex}`}
											onClick={() => {
												props.card === 'tenant' ? (day.status !== '' ? setShowHourwiseStatus(day.formattedDate) : null) :
													(day.status !== '' ? handleOpenbargraph(day.formattedDate) : null);
											}}
										>
											{day.day}
										</span>
									);
								})}
						</div>
					);
				})}
			</div>
			<div>
				{props.card !== 'tenant' && !loadingBar && datewiseStatus && <div><div className="selectedDate">{LABEL.LABEL_SELECTED_DATE}:  {moment(displayDate).subtract(1, 'days').format('DD MMM, YYYY')}</div><DateWiseStatus></DateWiseStatus></div>}
			</div>
			<div>{props.card === 'tenant' && showDaywiseStatus && <div>
				<div>
					<Dialog
						open={popupOpen}
						onClose={handlePopUpClose}
						hideBackdrop
						aria-labelledby="dialog-title"
						aria-describedby="dialog-description">
						<DialogTitle id="dialog-title">
							<Typography className="application-name" style={{ marginLeft: "15px", fontFamily: "CentraleSansBold, Helvetica, Arial, Verdana, Tahoma, sans-serif" }}>{LABEL.LABEL_24HOUR_DETAILS}  {moment(displayDate).subtract(1, 'days').format('DD MMM, YYYY')}</Typography>
							<Icon
								name="Cross"
								size="m"
								className={'dlsIcon header'}
								onClick={handlePopUpClose}
							/>
						</DialogTitle>
						<DialogContent style={{ height: "550px", marginLeft: "15px" }}>
							<DialogContentText id="dialog-description">
								<Typography variant="body2">
									<TenantDayWiseStatus tenantId={selectedTenant} isCalender={true}></TenantDayWiseStatus>
								</Typography>
							</DialogContentText>
						</DialogContent>
					</Dialog>
				</div>
			</div>
			}</div>

		</div>

	);
}
