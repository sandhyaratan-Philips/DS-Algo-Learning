/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import Calendar from './Calendar';
import store from "../../store/store";
import axios from 'axios';
import response from '../../mock/cloudApplicationListResponse.json';
import tenantListresponse from '../../mock/TenantApplicationListResponse.json';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('Calendar component', () => {

  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));


    it("Render Calendar component", () => {
      const card = 'tenant';
      renderWithContext(<Calendar props={card} />);
      });

      it('renders Calendar response from api response', async () => {
        const card = 'cloud';
        renderWithContext(<Calendar  props={card}/>);
        const mockedResponse: any = {
          data: response,
          status: 200,
          statusText: 'OK',
          headers: {},
          config: {},

        };
        mockedAxios.get.mockResolvedValue(mockedResponse);
        renderWithContext(<Calendar  props={card} />);
        expect(axios.get).toHaveBeenCalled();
      });
      it('renders Tenant History status response from api response', async () => {
        const card = 'tenant';
        renderWithContext(<Calendar  props={card}/>);
        const mockedResponse: any = {
          data: tenantListresponse,
          status: 200,
          statusText: 'OK',
          headers: {},
          config: {},

        };
        mockedAxios.get.mockResolvedValue(mockedResponse);
        renderWithContext(<Calendar  props={card} />);
        expect(axios.get).toHaveBeenCalled();
      });
      function renderWithContext(element: React.ReactElement) {
        render(
          <Provider store={store}>{element}</Provider>
        )
      }
});


