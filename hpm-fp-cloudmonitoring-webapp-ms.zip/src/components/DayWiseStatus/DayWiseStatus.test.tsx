/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import { render } from '@testing-library/react';
import DayWiseStatus from './DayWiseStatus';

const mockDispatch = jest.fn();
jest.mock('react-redux', () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch
}));

describe('DayWiseStatus component', () => {
  it('Dispatch action to fetch application list data', () => {
    render(<DayWiseStatus />);
  });
  it('Dispatch action to fetch application list data', () => {
    const mockedDispatch = jest.fn();
    expect(mockedDispatch).toBeDefined();
  });

});
