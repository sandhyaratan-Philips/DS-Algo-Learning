/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { styled } from "@mui/material/styles";
import {
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow
} from "@dls/react-mui-table";

import { FC, useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import { FabButton } from "@dls/react-mui-button";
import React from "react";
import { Icon } from "@dls/react-icon";
import clsx from "clsx";
import { environment } from "../../environment/environment";
import axios from "axios";
import { SetTenantTotalCount, TenantStatusList, SetTenantSort } from "../../store/actions";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store/store";
import TenantDayWiseStatus from "../TenantDayWiseStatus/TenantDayWiseStatus";
import Tooltip from '@mui/material/Tooltip';
import { LABEL } from "../Common/constants";
import { IconButton } from "@mui/material";
import * as  classConst from '../Common/util/util';

export default {
	title: "Core/Table",
	component: Table,
};

const classes = classConst.classes;

const Root = styled("div")({
	[`& .${classes.root}`]: {
		width: "100%",
	},
	[`& .${classes.paper}`]: {
		width: "100%",
	},
	[`& .${classes.table}`]: {
		minWidth: 650,
	},
	[`& .${classes.visuallyHidden}`]: {
		border: 0,
		clip: "rect(0 0 0 0)",
		height: 1,
		margin: -1,
		overflow: "hidden",
		padding: 0,
		position: "absolute",
		top: 20,
		width: 1,
	},
	[`& .${classes.checkbox}`]: {
		display: "flex",
	},
	[`& .${classes.truncating}`]: {
		whiteSpace: "nowrap",
		maxWidth: "300px",
		width: "100px",
		overflow: "hidden",
		textOverflow: "ellipsis",
	},
});

const PREFIXROW = "Row";
const rowclasses = {
	root: `${PREFIXROW}-root`,
};
const TableRowRoot = styled(TableRow)({
	[`&.${rowclasses.root}`]: {
		"& > *": {
			borderBottom: "unset",
		},
	},
});

function Row(props: { row: any }) {
	const row = props;
	const [open, setOpen] = React.useState(false);


	return (
		<React.Fragment>
			<TableRowRoot className={clsx(rowclasses.root, "toggle-row")} >
				<TableCell style={{ marginLeft: "0px", height: "50px" }}
					scope="row"><Tooltip title={row.row.tenantName}><span>{row.row.tenantName.length > 28 ? row.row.tenantName.slice(0, 28) + "..." : row.row.tenantName}</span></Tooltip>
				</TableCell>
				{row.row.status.map((data: any, index: number) => (
					<TableCell key={`${index}_TableCell`}>
						<Tooltip
							title={
								data.status === "UP"
									? LABEL.HEALTHY
									: data.status === "DOWN"
										? LABEL.NEEDS_ATTENTION
										: data.status === "NORECORDS"
											? LABEL.NO_RECORDS
											: LABEL.NEEDS_ATTENTION
							}
							arrow
						>
							<span
								className="dot"
								style={{
									height: "20px",
									backgroundColor: data.status === "UP" ? "#5F9920" : data.status === "DOWN" ? "#DE7510" : data.status === "NORECORDS" ? "#9E9E9E" : "#FF0000",
									width: "20px",
									borderRadius: "50%",
									display: "inline-block",
									opacity: "100%",
									textAlign: "center",
								}}
							></span>
						</Tooltip>
					</TableCell>
				))}
				<TableCell className={"toggle-cell"}>
					<FabButton
						size="small"
						variant="extended"
						dls_variant="quietDefault"
						onClick={() => setOpen(!open)}
					>
						{open ? (
							<Icon name={"NavigationUp"} size={"m"} />
						) : (
							<Icon name={"NavigationDown"} size={"m"} />
						)}
					</FabButton>
				</TableCell>
			</TableRowRoot>

			<TableRow
				className={"collapsible-row"}
				style={{ display: open ? "" : "none" }}
			>
				<TableCell
					style={{ paddingBottom: 0, paddingTop: 0 }}
					className={"collapsible-cell"}
					colSpan={6}
				>
					<Collapse in={open} timeout="auto" unmountOnExit>
						<Box margin={1}>
							<div style={{ display: "flex", height: "12rem" }}>
								<div style={{ marginTop: "-1rem", marginLeft: "60px" }}>
									<TenantDayWiseStatus tenantId={row.row.tenantId}></TenantDayWiseStatus>
								</div>
							</div>
						</Box>
					</Collapse>
				</TableCell>
			</TableRow>
		</React.Fragment>
	);
}
export const CollapsibleTable: FC = () => {
	const dispatch = useDispatch();
	const tenantList = useSelector((state: RootState) => state.list.tenantList);
	const [headerName, setHeaderName] = useState([] as string[]);
	const TENANT_CONNECTION_URL = environment.BASE_URL + "/HealthCheck/tenantConnectionStatus";
	const [showIcon, setShowIcon] = useState(false);
	const tenantpageSize = useSelector((state: RootState) => state.list.pageSize);
	const tenantSort = useSelector((state: RootState) => state.list.tenantSort);
	const tenantPageIndex = useSelector((state: RootState) => state.list.pageIndex);
	const searchTenant = useSelector((state: RootState) => state.list.searchTenant);

	useEffect(() => {
		const date: Date = new Date();
		const today = date.toISOString().split(".")[0] + "Z";
		const yesterday =
			new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
				.toISOString()
				.split(".")[0] + "Z";
		const headerData: string[] = [];
		axios
			.get(TENANT_CONNECTION_URL,
				{
					params: {
						daywiseStatus: true,
						start: yesterday,
						end: today,
						pageNumber: tenantPageIndex + 1,
						tenantName: "",
						recordsPerPage: tenantpageSize,
						sortingOrder: tenantSort
					},
					headers: {
						Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
					}
				}
			)
			.then((response) => {
				headerData.push('Tenant Name');
				const applicationStatus = response.data[0].status;
				applicationStatus.map((a: any) => {
					headerData.push(a.displayName);
				});
				dispatch(TenantStatusList(response.data));
				dispatch(SetTenantTotalCount(response.data[0].totalRecords));
			});
		setHeaderName(headerData);
	}, []);

	const sortlist = (eventName: string) => {
		const date: Date = new Date();
		const today = date.toISOString().split('.')[0] + "Z";
		const yesterday =
			new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
				.toISOString()
				.split('.')[0] + "Z";

		if (eventName === "arrowDown") {
			setShowIcon(true);
		} else {
			setShowIcon(false);
		}
		dispatch(SetTenantSort(eventName === "arrowDown" ? "desc" : "asc"));
		axios
			.get(TENANT_CONNECTION_URL, {
				params: {
					daywiseStatus: true,
					start: yesterday,
					end: today,
					pageNumber: tenantPageIndex + 1,
					tenantName: searchTenant || "",
					recordsPerPage: tenantpageSize,
					sortingOrder: eventName === "arrowDown" ? "desc" : "asc",
				},
				headers: {
					Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
				}
			})
			.then((response) => {
				dispatch(TenantStatusList(response.data));
			});
	};

	return (
		<TableContainer style={{ height: '340px', overflow: 'auto', color: 'grey' }} >
			{tenantList.length !== 0 &&
				<Table aria-label="collapsible table" className={"collapsibletable"}>
					<TableHead>
						<TableRow >
							{headerName.length > 2 && headerName.map((headerObj: any) => (
								<TableCell style={{ fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: '15px', color: '', lineHeight: '22px', fontWeight: '400', opacity: '100%' }} key={headerObj} >
									{headerObj}
									{headerObj === 'Tenant Name' && (
										<IconButton className="icon-btn">
											{showIcon ? (
												<Icon
													name={"ArrowUp"}
													className={"ArrowDown-icon"}
													size={"l"}
													onClick={() => sortlist("arrowUp")}
												/>
											) : (
												<Icon
													name={"ArrowDown"}
													className={"ArrowDown-icon"}
													size={"l"}
													style={{ color: 'grey' }}
													onClick={() => sortlist("arrowDown")}
												/>
											)}
										</IconButton>
									)}
								</TableCell>
							))}
							<TableCell></TableCell>
						</TableRow>
					</TableHead>
					<TableBody
						style={{ fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: '15px', color: '#1474A4', textAlign: 'center', lineHeight: '22px', fontWeight: '500', opacity: '100%' }}>
						{tenantList.map((data: any, index: number) => (
							<Row key={`${index}_collapse`} row={data} />
						))}
					</TableBody>
				</Table>
			}
		</TableContainer>
	);
};
