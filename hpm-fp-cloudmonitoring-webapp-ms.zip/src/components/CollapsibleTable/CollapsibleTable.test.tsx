
import {  screen } from '@testing-library/react';


describe('CollapsibleTable component', () => {
  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));

  it("checking the Card header to be TenandId", () => {
    setTimeout(() => {
      const TenandId = screen.getByTestId("Card-header");
      expect(TenandId).toBeInTheDocument();
    }, 5000)
});

  it("checking the Card title to be Tenant Connection Status", () => {
    setTimeout(() => {
      const tenantCard = screen.getByTestId("Card-title");
      expect(tenantCard).toBeInTheDocument();
    }, 5000)

  });

})