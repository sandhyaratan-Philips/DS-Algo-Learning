/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import * as React from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
import './ListDetails.scss';
import { RootState } from '../../store/store';
import { getList, setList, SetSorting, setApplicationName, SetDatewiseStatus, SetTenantId, SetTenantNameList, SetTenantSort, setApplicationList } from '../../store/actions';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import Tooltip from '@mui/material/Tooltip';
import { ApplicationInfo, AppList, TenantNameList } from '../../store/types';
import { Icon } from "@dls/react-icon";
import { IconButton } from "@mui/material";
import { environment } from '../../environment/environment';
import axios from 'axios';
import * as  service from '../Services/Service';
import Alert from "react-bootstrap/Alert";

const ListDetails = (props: any) => {
  const dispatch = useDispatch();
  const list = useSelector((state: RootState) => state.list.lists);
  const sort = useSelector((state: RootState) => state.list.sort);
  const pageIndex = useSelector((state: RootState) => state.list.queryPageIndex);
  const pageSize = useSelector((state: RootState) => state.list.queryPageSize);
  const appList = useSelector((state: RootState) => state.list.appList);
  const status = useSelector((state: RootState) => state.list.status);
  const selectedApp = useSelector((state: RootState) => state.list.selectedApplication);
  const [showIcon, setShowIcon] = useState(false);
  const CLOUD_HEALTH_STATUS_URL = environment.BASE_URL + '/HealthCheck';
  const tenantStatus = useSelector((state: RootState) => state.list.tenantStatus);
  const tenantList = useSelector((state: RootState) => state.list.tenantNameList);
  const selectedTenant = useSelector((state: RootState) => state.list.selectedTenant);
  const searchStatus = useSelector((state: RootState) => state.list.displayStatus);
  const TENANT_STATUS_URL = environment.BASE_URL + '/HealthCheck/tenants';
  const tenantSort = useSelector((state: RootState) => state.list.tenantSort);
  const [errorMessage, setErrorMessage] = useState('');
  const tenantPageIndex = useSelector((state: RootState) => state.list.pageIndex);
  const tenantpageSize = useSelector((state: RootState) => state.list.pageSize);
  const isSearch = useSelector((state: RootState) => state.list.isSearch);
  const searchApplication = useSelector((state: RootState) => state.list.searchApplication);
  const searchTenant = useSelector((state: RootState) => state.list.searchTenant);

  const date: Date = new Date();
  const today = date.toISOString().split('.')[0] + "Z";
  const yesterday =
    new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
      .toISOString()
      .split('.')[0] + "Z";

  useEffect(() => {
    dispatch(getList());
  }, []);
  useEffect(() => {
    dispatch(SetDatewiseStatus(false));

  }, [selectedApp]);

  const handleClick = (applicationName: string) => {
    dispatch(setApplicationName(applicationName));
  };
  const handleSelectedTenant = (tenantName: string, tenantId: string,) => {
    dispatch(SetTenantId(tenantId));
  };
  const sortlist = async (eventName: string) => {
    if (eventName === 'arrowDown') {
      setShowIcon(true);
    }
    else {
      setShowIcon(false);
    }
    if (props.card === 'tenant' && !tenantStatus) {
      dispatch(SetTenantSort(eventName === 'arrowDown' ? 'desc' : 'asc'));
      await axios
        .get(CLOUD_HEALTH_STATUS_URL, {
          params: {
            daywiseStatus: true,
            start: yesterday,
            end: today,
            pageNumber: pageIndex + 1,
            recordsPerPage: pageSize,
            tenantName: searchTenant || '',
            sortingOrder: sort
          },
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
          }
        })
        .then((response) => {
          dispatch(setList(response.data));
        });

    } else if (props.card === 'tenant' && tenantStatus) {
      dispatch(SetTenantSort(eventName === 'arrowDown' ? 'desc' : 'asc'));
      try {
        const params: any = {
          pageNumber: tenantPageIndex + 1,
          recordsPerPage: tenantpageSize,
          sortingOrder: tenantSort,
          tenantName: searchTenant || ''
        }
        await service.getDetails(TENANT_STATUS_URL, params).then((response: any) => {
          const res = response.data;
          dispatch(SetTenantId(res.data[0].tenantId));
          dispatch(SetTenantNameList(response.data.data));
          dispatch(getList());
        });
      } catch (error) {
        setErrorMessage("No Data Available");
      }
    } else {
      dispatch(SetSorting(eventName === 'arrowDown' ? 'desc' : 'asc'));
      await axios
        .get(CLOUD_HEALTH_STATUS_URL, {
          params: {
            daywiseStatus: true,
            start: yesterday,
            end: today,
            pageNumber: pageIndex + 1,
            recordsPerPage: pageSize,
            applicationName: isSearch ? searchApplication : '',
            sortingOrder: sort
          },
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
          }
        })
        .then((response) => {
          dispatch(setList(response.data));
          dispatch(setApplicationList(response.data));
        });
    }
  };


  if (errorMessage)
    return (
      <div data-testid="titleTenant">
        <Alert>{errorMessage}</Alert>
      </div>
    );
  return (
    <>
      {searchStatus &&
        <div className="list-container-title">
          <span
            style={{
              fontFamily: "CentraleSansMedium,Helvetica, Arial, Verdana, Tahoma, sans-serif",
              textAlign: "left",
              marginTop: "20px",
              fontWeight: "400",
              position: "relative",
              opacity: "100%",
              width: "193px",
              fontSize: "16px",
              color: "#1474A4"
            }}
          >
            {props.card !== 'tenant' ? "Cloud services" : "Tenant Name"} {" "}
          </span>
          <IconButton className="icon-btn" onClick={() => sortlist(showIcon ? 'arrowUp' : 'arrowDown')}>
            {showIcon ? (
              <Icon
                name={"ArrowUp"}
                className={"ArrowDown-icon"}
                size={"l"}
              />
            ) : (
              <Icon
                name={"ArrowDown"}
                className={"ArrowUp-icon"}
                size={"l"}
              />
            )}
          </IconButton>
        </div>
      }

      <div data-testid="HistoryList">
        {status && props.card !== 'tenant' ?
          <div>
            {appList && appList.length > 0 &&
              <ListGroup className="ListGroup-style" data-testid="ListGroup" variant="flush" style={{ marginLeft: "19px", marginTop: "-7px" }}>
                {
                  appList.map((a: AppList, index: number) => {
                    return (
                      <ListGroup.Item action data-testid="listItem" key={`${index}_ListGroup`} className={`ListGroup-Item list-item ${selectedApp == a.applicationName?.toString() ? 'active' : null}`} onClick={() => { handleClick(a.applicationName) }}><Tooltip title={a.displayName}><span>{a.displayName.length > 29 ? a.displayName.slice(0, 29) + "..." : a.displayName}</span></Tooltip></ListGroup.Item>
                    );
                  })
                }
              </ListGroup>
            }
          </div>
          :
          tenantStatus && props.card === 'tenant' ?
            <div>
              {tenantList && tenantList.length > 0 &&
                <ListGroup className="ListGroup-style" data-testid="ListGroup" variant="flush" style={{ marginLeft: "19px", marginTop: "-7px" }}>
                  {
                    tenantList.map((a: TenantNameList) => {
                      return (
                        <ListGroup.Item action data-testid="listItem" key={a.tenantId?.toString()} className={`ListGroup-Item list-item ${selectedTenant == a.tenantId?.toString() ? 'active' : null}`} onClick={() => { handleSelectedTenant(a.tenantName, a.tenantId) }}><Tooltip title={a.tenantName}><span>{a.tenantName.length > 20 ? a.tenantName.slice(0, 20) + "..." : a.tenantName}</span></Tooltip></ListGroup.Item>
                      );
                    })
                  }
                </ListGroup>
              }
            </div>
            :
            <div data-testid="list-details">
              <ListGroup className="ListGroup-style"
                style={{ marginLeft: "19px", marginTop: "-7px" }}
                data-testid="ListGroup" variant="flush">
                {
                  list.map((application: ApplicationInfo, index: number) => {
                    return (
                      <ListGroup.Item data-testid="listItem" key={`${index}_ListGroupItem`} className="ListGroup-Item list-item"><Tooltip title={application.displayName}><span>{application.displayName.length > 29 ? application.displayName.slice(0, 29) + "..." : application.displayName}</span></Tooltip></ListGroup.Item>
                    );
                  })
                }
              </ListGroup>
            </div>
        }
      </div>
    </>
  );
};

export default ListDetails;
