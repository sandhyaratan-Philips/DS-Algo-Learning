/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import React from "react";
import { screen, render } from "@testing-library/react";
import ListDetails from "./ListDetails";
import store from "../../store/store";
import { Provider } from "react-redux";


describe("ListDetails component to be present in ui", () => {
  const mockDispatch = jest.fn();
  renderWithContext(<ListDetails />);

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));

  it("descList to be in the document", () => {
    renderWithContext(<ListDetails />);
    expect('descList').toBeInTheDocument;
  });

  it("ascList to be in the document", () => {
    renderWithContext(<ListDetails />);
    expect('ascList').toBeInTheDocument;
  });

  it("HistoryList to be in the document", () => {
    renderWithContext(<ListDetails />);
    const historyList = screen.getByTestId("HistoryList");
    expect(historyList).toBeInTheDocument();

  });

  function renderWithContext(element: React.ReactElement) {
    render(
      <Provider store={store}>{element}</Provider>
    )
  }
});

