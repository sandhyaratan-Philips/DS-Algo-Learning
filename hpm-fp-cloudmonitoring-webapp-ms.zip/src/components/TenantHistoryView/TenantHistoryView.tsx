/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        27/03/2023 02:00:00 PM
 *
 **/

import { useEffect, useState } from "react";
import ListDetails from "../List/ListDetails";
import { useDispatch, useSelector } from "react-redux";
import * as  service from '../Services/Service';
import { getList, SetTenantId, SetTenantNameList } from "../../store/actions";
import Alert from "react-bootstrap/Alert";
import { Col, Row } from "react-bootstrap";
import Calendar from "../Calendar/Calendar";
import { RootState } from "../../store/store";
import Spinner from "react-bootstrap/Spinner";
import { environment } from "../../environment/environment";

export default function TenantHistoryView() {
    const dispatch = useDispatch();
    const [errorMessage, setErrorMessage] = useState('');
    const [loadingData, setLoadingData] = useState(true);
    const selectedTenant = useSelector((state: RootState) => state.list.selectedTenant);
    const cardName = 'tenant';
    const TENANT_STATUS_URL = environment.BASE_URL + '/HealthCheck/tenants';
    const tenantPageIndex = useSelector((state: RootState) => state.list.pageIndex);
    const tenantpageSize = useSelector((state: RootState) => state.list.pageSize);
    const tenantSort = useSelector((state: RootState) => state.list.tenantSort);
    const tenantSearchResult = useSelector((state: RootState) => state.list.tenantSearchResult);

    useEffect(() => {
        getTenantList();
    }, []);

    const getTenantList = async () => {
        try {
            const params: any = {
                pageNumber: tenantPageIndex + 1,
                recordsPerPage: tenantpageSize,
                sortingOrder: tenantSort,
                tenantName: ''
            }
            await service.getDetails(TENANT_STATUS_URL, params).then((response: any) => {
                const res = response.data;
                dispatch(SetTenantId(res.data[0].tenantId));
                dispatch(SetTenantNameList(response.data.data));
                dispatch(getList());
            });
        } catch (error) {
            setErrorMessage("No Data Available");

        }
        finally {
            setLoadingData(false);
        }
    }

    if (loadingData) {
        return (
            <div className="spinner-style" data-testid="loading">
                <Spinner animation="border" variant="dark" />
            </div>
        );
    }
    if (errorMessage) {
        return (
            <div data-testid="titleTenant">
                <Alert>{errorMessage}</Alert>
            </div>
        );
    }
    return (

        <Row className="row-container" data-testid="tenantHistory">

            <Col md={4}>
                <div>
                    {tenantSearchResult &&
                        <ListDetails card={cardName}></ListDetails>
                    }
                </div>
            </Col>
            <Col md={8} className="midPannel">
                <div>
                    {tenantSearchResult && selectedTenant.length !== 0 && <Calendar card={cardName}></Calendar>}
                </div>
            </Col>

        </Row>

    );
}
