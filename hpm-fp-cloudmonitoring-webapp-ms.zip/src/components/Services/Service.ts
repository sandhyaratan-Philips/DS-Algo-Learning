/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        15/03/2023 03:00:00 PM
 *
 **/
import axios from "axios";

export function getDetails(url: string, payload: any): Promise<any> {
	return axios.get(url, {
		params: payload, headers: {
			Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
		}
	});
}
export function getUserPreferenceDetails(url: string, payload: any): Promise<any> {
	return axios.get(url, {
		params: payload, headers: {
			Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
		}
	});
}
export function editUserPreferenceDetails(url: string, payload: any): Promise<any> {
	return axios.put(url,
		payload, {
			headers: {
				Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
			}
	});
}
export function createUserPreference(url: string, payload: any): Promise<any> {
	return axios.post(url,
		payload, {
			headers: {
				Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
			}
	});
}
export function licenseDetails(url: string, payload: any): Promise<any> {
	return axios.get(url, {
		params: payload, headers: {
			Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
		}
	});
}
export function exportLicenseList(url: string, payload: any): Promise<any> {
	return axios.get(url, {
		params: payload, headers: {
			Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`,
			responseType: 'blob'
		}
	});
}