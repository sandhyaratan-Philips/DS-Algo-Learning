/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Harsha
 * Date:        30/03/2023 03:00:00 PM
 *
 **/

import axios from "axios";
import { LoginUserRequest } from "../../models/SessionRequests";

export function authenticate(url: string, payload: LoginUserRequest): Promise<any> {
	return axios.post(url, payload, { withCredentials: true });
}

export function validateUserSession(url: string): Promise<any> {
	return axios.get(url, { withCredentials: true });
}

export function renewSession(url: string, token: string): Promise<any> {
	const headers = {
		Authorization: `Bearer ${token}`
	};
	return axios.post(url, null, { headers });
}

export function logoutUser(url: string): Promise<any> {
	return axios.post(url, null, { withCredentials: true });
}