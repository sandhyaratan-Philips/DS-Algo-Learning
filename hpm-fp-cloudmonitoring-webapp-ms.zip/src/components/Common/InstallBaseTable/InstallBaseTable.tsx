/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      divyashree um
 * Date:        22/08/2023 03:00:PM
 *
 **/
import React, { useEffect, useState } from 'react';
import { TableContainer, Table, TableHead } from '@dls/react-mui-table';
import { styled } from '@mui/material/styles';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { TableBody, TableCell, TableRow, Typography } from '@dls/react-core';
import { IconButton } from '@mui/material';
import { Icon } from "@dls/react-icon";
import { RootState } from '../../../store/store';
import { environment } from '../../../environment/environment';
import { SetLicenseSorting, SetLicenseData } from '../../../store/actions/listActions';
import { useSortBy, useTable } from 'react-table';
import * as service from '../../Services/Service';
import { setSessionErrorMessage } from '../util/util';
import moment from "moment";
import { LABEL, licenseDataColumns } from "../constants";
import Tooltip from '@mui/material/Tooltip';

export default {
    title: 'Core/DataGrid',
    component: Table,
};

const PREFIX = 'DataGrid';

const classes = {
    root: `${PREFIX}-root`,
    paper: `${PREFIX}-paper`,

    table: `${PREFIX}-table`,
    visuallyHidden: `${PREFIX}-visuallyHidden`,
    truncating: `${PREFIX}-truncating`,
    expandedRow: `${PREFIX}-expandedRow`,
    checkbox: `${PREFIX}-checkbox`,
    title: `${PREFIX}-title`,
};


const Root = styled('div')({
    [`& .${classes.root}`]: {
        width: '100%',
    },
    [`& .${classes.paper}`]: {
        width: '100%',
    },
    [`& .${classes.table}`]: {
        minWidth: 650,
    },
    [`& .${classes.visuallyHidden}`]: {
        border: 0,
        clip: 'rect(0 0 0 0)',
        height: 1,
        margin: -1,
        overflow: 'hidden',
        padding: 0,
        position: 'absolute',
        top: 20,
        width: 1,
    },
    [`& .${classes.checkbox}`]: {
        display: 'flex',
    },
    [`& .${classes.truncating}`]: {
        whiteSpace: 'nowrap',
        maxWidth: '300px',
        width: '100px',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
    },
});

function createData(
    tenantName: string,
    licenseType: string,
    productVersion: string,
    bedDetails: number,
    activationDate: string,
) {
    return { tenantName, licenseType, productVersion, bedDetails, activationDate };
}

export const InstallBaseTable = ({ tabledata }: { tabledata: any }) => {
    const dispatch = useDispatch();
    const [showIcon, setShowIcon] = useState(false);
    const searchLicense = useSelector((state: RootState) => state.license.searchLicense);
    const licensePageIndex = useSelector((state: RootState) => state.license.licensePageIndex);
    const licensePageSize = useSelector((state: RootState) => state.license.licensePageSize);
    const licenseSort = useSelector((state: RootState) => state.license.licenseSort);
    const LICENSE_CONNECTION_URL = environment.BASE_URL + "/InstallBase";
    const [, setErrorMessage] = useState('');
    const [recordsFound, setRecordsFound] = useState(true);

    useEffect(() => {
        if (tabledata && tabledata.length > 0) {
            setRecordsFound(true);
        } else {
            setRecordsFound(false);
        }
    }, [tabledata]);


    const data = React.useMemo(() => {
        if (
            tabledata && tabledata.length
        ) {
            return tabledata.map((item: any) => {
                return createData(item.tenantName, item.licenseType, item.productVersion, item.bedDetails, moment(item.activationDate).format());
            })
        } else {
            return []
        }
    }, [tabledata]);

    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } =
        useTable(
            {
                columns: licenseDataColumns,
                data,
            },
            useSortBy,
        );

    const sortLicenseData = async (eventName: string) => {
        if (eventName === 'arrowDown') {
            setShowIcon(true);
        }
        else {
            setShowIcon(false);
        }
        dispatch(SetLicenseSorting(eventName === 'arrowDown' ? 'desc' : 'asc'));
        if (licensePageIndex !== 0) {
            try {
                const params = {
                    pageNumber: licensePageIndex + 1,
                    recordsPerPage: licensePageSize,
                    sortingOrder: licenseSort,
                    tenantName: searchLicense || ''
                };

                const response = await service.getDetails(LICENSE_CONNECTION_URL, params);
                dispatch(SetLicenseData(response.data.data));
                setSessionErrorMessage('');
            } catch (error) {
                setErrorMessage("No Data Available");
            }
        }
    }

    return (
        <Root>
            <br>
            </br>
            {recordsFound ? (
                <TableContainer>
                    {
                        <Table
                            className={classes.table}
                            aria-label="simple table"
                            {...getTableProps()}>
                            <TableHead>
                                {headerGroups.map((headerGroup: any) => (
                                    <TableRow
                                        key={headerGroup.name}
                                        {...headerGroup.getHeaderGroupProps()}>
                                        {headerGroup.headers.map((column: any) => (
                                            <TableCell style={{ paddingLeft: "15px" }}
                                                key={column.id}
                                                {...column.getHeaderProps(column.getSortByToggleProps())}>
                                                <Typography
                                                    weight="bold"
                                                    style={{ fontSize: "16px" }}
                                                    id="tableTitle">
                                                    {column.render('Header')}
                                                    {
                                                        column.id === "tenantName" ? (showIcon ? <IconButton >
                                                            <Icon name={'ArrowUp'} size={'l'} style={{ marginBottom: "8px" }} className='ArrowUp-icon'
                                                                onClick={() => sortLicenseData('arrowUp')} />
                                                        </IconButton> : <IconButton >
                                                            <Icon name={'ArrowDown'} size={'l'} style={{ marginBottom: "8px" }} className='ArrowDown-icon'
                                                                onClick={() => sortLicenseData('arrowDown')} />
                                                        </IconButton>)
                                                            : ""
                                                    }
                                                </Typography>
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))}
                            </TableHead>
                            <TableBody {...getTableBodyProps()} >
                                {rows.map((row: any) => {
                                    prepareRow(row);
                                    return (
                                        <TableRow key={row.name} {...row.getRowProps()}>
                                            {row.cells.map((cell: any) => {
                                                return (
                                                    <TableCell key={cell.name} {...cell.getCellProps()}>
                                                        {cell.column.id === "tenantName" ? (
                                                            <Tooltip title={cell.value}>
                                                                <span className={classes.truncating}>
                                                                    {cell.value.length > 25 ? cell.value.slice(0, 25) + "..." : cell.value}
                                                                </span>
                                                            </Tooltip>
                                                        ) : (
                                                            cell.render('Cell')
                                                        )}
                                                    </TableCell>
                                                );
                                            })}
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    }
                </TableContainer>
            ) : (
                <span className="validation-error" style={{ marginLeft: "40px", marginBottom: "30px", color: "red", display: "flex", marginTop: "-16px" }}>
                    <Icon name="InformationCircleOutline" size={"s"} style={{ color: 'red', marginTop: "-3px", marginLeft: "-10px", marginBottom: "-20px" }} />
                    <div>
                        {LABEL.CUSTOMER_NAME_IS_NOT_FOUND}
                    </div>
                </span>
            )}
        </Root >
    );
}

