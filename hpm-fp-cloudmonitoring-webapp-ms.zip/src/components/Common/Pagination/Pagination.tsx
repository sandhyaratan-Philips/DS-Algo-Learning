/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/02/2023 10:00:00 AM
 *
 **/
import * as React from "react";
import { useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { setList, SetPage, SetPageSize, setApplicationList, setApplicationName, SetDatewiseStatus, TenantStatusList, SetTenantTotalCount, SetTenantPageSize, SetTenantPage, SetTenantId, SetTenantNameList, getList, SetUserPageSize, SetUserPage, SetLicensePageSize, SetLicensePage, SetLicenseData, SetLicenseTotalCount } from '../../../store/actions';
import { LABEL } from "../../Common/constants";
import { RootState } from "../../../store/store";
import { environment } from "../../../environment/environment";
import { Typography } from '@dls/react-mui-typography';
import TablePagination from '@mui/material/TablePagination';
import { Paper } from '@dls/react-mui-paper';
import * as  service from '../../Services/Service';
export const Pagination = (props: any) => {
    const dispatch = useDispatch();
    const pageIndex = useSelector((state: RootState) => state.list.queryPageIndex);
    const pageSize = useSelector((state: RootState) => state.list.queryPageSize);
    const totalCount = useSelector((state: RootState) => state.list.totalCount);
    const isSearch = useSelector((state: RootState) => state.list.isSearch);
    const sort = useSelector((state: RootState) => state.list.sort);
    const status = useSelector((state: RootState) => state.list.status);
    const CLOUD_HEALTH_STATUS__APPLICATION_URL = environment.BASE_URL + '/HealthCheck/applications';
    const CLOUD_HEALTH_STATUS_URL = environment.BASE_URL + '/HealthCheck';
    const TENANT_CONNECTION_URL = environment.BASE_URL + "/HealthCheck/tenantConnectionStatus";
    const tenantPageIndex = useSelector((state: RootState) => state.list.pageIndex);
    const tenantpageSize = useSelector((state: RootState) => state.list.pageSize);
    const tableTotalCount = useSelector((state: RootState) => state.list.totalTenant);
    const tenantStatus = useSelector((state: RootState) => state.list.tenantStatus);
    const TENANT_STATUS_URL = environment.BASE_URL + '/HealthCheck/tenants';
    const tenantSort = useSelector((state: RootState) => state.list.tenantSort);
    const userPageIndex = useSelector((state: RootState) => state.user.userPageIndex);
    const userPageSize = useSelector((state: RootState) => state.user.userPageSize);
    const totalUserPeference = useSelector((state: RootState) => state.user.totalUserPeference);
    const searchApplication = useSelector((state: RootState) => state.list.searchApplication);
    const searchTenant = useSelector((state: RootState) => state.list.searchTenant);
    const searchLicense = useSelector((state: RootState) => state.license.searchLicense);
    const licensePageIndex = useSelector((state: RootState) => state.license.licensePageIndex);
    const licensePageSize = useSelector((state: RootState) => state.license.licensePageSize);
    const licenseTotalCount = useSelector((state: RootState) => state.license.totalLicense);
    const licenseSort = useSelector((state: RootState) => state.license.licenseSort);
    const LICENSE_CONNECTION_URL = environment.BASE_URL + "/InstallBase";

    useEffect(() => {
        if (props.card === 'cloud') {
            getCloudHealthstatus();
        }
    }, [pageSize, pageIndex, sort, status]);

    useEffect(() => {
        if (props.card === 'tenant') {
            getTenantConnectionStatus();
        }
    }, [tenantPageIndex, tenantpageSize, tenantSort, tenantStatus]);

    useEffect(() => {
        if (props.card === 'license') {
            getLicenseDetails();
        }
    }, [licensePageIndex, licensePageSize, licenseSort]);

    const getTenantConnectionStatus = () => {
        if (tenantStatus) {
            dispatch(SetTenantPageSize(tenantpageSize));
            dispatch(SetTenantPage(tenantPageIndex));
            const params: any = {
                pageNumber: tenantPageIndex + 1,
                recordsPerPage: tenantpageSize,
                sortingOrder: 'asc',
                tenantName: searchTenant || ""
            }
            service.getDetails(TENANT_STATUS_URL, params).then((response: any) => {
                const res = response.data;
                dispatch(SetTenantId(res.data[0].tenantId));
                dispatch(SetTenantNameList(response.data.data));
                dispatch(getList());
            });

        } else {
            dispatch(SetTenantPageSize(tenantpageSize));
            dispatch(SetTenantPage(tenantPageIndex));
            const date: Date = new Date();
            const today = date.toISOString().split('.')[0] + "Z";
            const yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).toISOString().split('.')[0] + "Z";

            const params: any = {
                start: yesterday,
                end: today,
                tenantName: "",
                pageNumber: tenantPageIndex + 1,
                recordsPerPage: tenantpageSize,
                sortingOrder: tenantSort
            }
            if (!isSearch || pageIndex !== 0) {
                service.getDetails(TENANT_CONNECTION_URL, params).then((response: any) => {
                    dispatch(TenantStatusList(response.data));
                    dispatch(SetTenantId(response.data[0].tenantId));
                    dispatch(SetTenantTotalCount(response.data[0].totalRecords));
                });
            }
        }

    }
    const getCloudHealthstatus = async () => {
        dispatch(SetDatewiseStatus(false));
        if (status) {
            dispatch(SetPageSize(pageSize));
            dispatch(SetPage(pageIndex));
            const params: any = {
                applicationName: isSearch ? searchApplication : '',
                pageNumber: pageIndex + 1,
                recordsPerPage: pageSize,
                sortingOrder: sort
            }
            service.getDetails(CLOUD_HEALTH_STATUS__APPLICATION_URL, params).then((response: any) => {
                dispatch(setApplicationName(response.data.data[0].applicationName));
                dispatch(setApplicationList(response.data.data));
            });

        } else {
            dispatch(SetPageSize(pageSize));
            dispatch(SetPage(pageIndex));
            const date: Date = new Date();
            const today = date.toISOString().split('.')[0] + "Z";
            const yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).toISOString().split('.')[0] + "Z";
            const params: any = {
                daywiseStatus: true,
                start: yesterday,
                end: today,
                pageNumber: pageIndex + 1,
                recordsPerPage: pageSize,
                applicationName: isSearch ? searchApplication : '',
                sortingOrder: sort
            }
            service.getDetails(CLOUD_HEALTH_STATUS_URL, params).then((response: any) => {
                dispatch(setList(response.data));
            });
        }
    }
    const getLicenseDetails = async () => {
        dispatch(SetLicensePageSize(licensePageSize));
        dispatch(SetLicensePage(licensePageIndex));
        const params: any = {
            tenantName: isSearch ? searchLicense : '',
            pageNumber: licensePageIndex + 1,
            recordsPerPage: licensePageSize,
            sortingOrder: licenseSort
        }
        service.licenseDetails(LICENSE_CONNECTION_URL, params).then((response: any) => {
            dispatch(SetLicenseData(response.data.data));
            dispatch(SetLicenseTotalCount(response.data.totalRecords));
        });

    }

    const MenuProps: Record<string, unknown> = {
        PaperProps: {
            className: `DLSDropdownList`,
            component: Paper,
        }
    };
    const handleChangePage = (event: any, newPage: number) => {
        if (props.card === 'tenant') {
            dispatch(SetTenantPage(newPage));
        } else if (props.card === 'cloud') {
            dispatch(SetPage(newPage));
        } else if (props.card === 'license') {
            dispatch(SetLicensePage(newPage));
        } else {
            dispatch(SetUserPage(newPage));
        }
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>,
    ) => {
        if (props.card === 'tenant') {
            const pageSizeValue = parseInt(event.target.value);
            dispatch(SetTenantPage(0));
            dispatch(SetTenantPageSize(pageSizeValue));

        } else if (props.card === 'cloud') {
            const pageSizeValue = parseInt(event.target.value);
            dispatch(SetPage(0));
            dispatch(SetPageSize(pageSizeValue));

        } else if (props.card === 'license') {
            const pageSizeValue = parseInt(event.target.value);
            dispatch(SetLicensePage(0));
            dispatch(SetLicensePageSize(pageSizeValue));
        }
        else {
            const pageSizeValue = parseInt(event.target.value);
            dispatch(SetUserPage(0));
            dispatch(SetUserPageSize(pageSizeValue));
        }
    };
    const setCount = () => {
        if (props.card === 'tenant') {
            return tableTotalCount;
        } else if (props.card === 'cloud') {
            return totalCount;
        } else if (props.card === 'license') {
            return licenseTotalCount;
        } else {
            return totalUserPeference;
        }

    }
    const setRowsPerPage = () => {
        if (props.card === 'tenant') {
            return tenantpageSize;
        } else if (props.card === 'cloud') {
            return pageSize;
        } else if (props.card === 'license') {
            return licensePageSize;
        } else {
            return userPageSize;
        }
    }
    const setPageIndex = () => {
        if (props.card === 'tenant') {
            return tenantPageIndex;
        } else if (props.card === 'cloud') {
            return pageIndex;
        } else if (props.card === 'license') {
            return licensePageIndex;
        } else {
            return userPageIndex;
        }
    }

    return (
        <Paper>
            <TablePagination
                rowsPerPageOptions={props.card === 'license' ? [5, 10, 15] : [5, 10]}
                component="div"
                count={setCount()}
                rowsPerPage={setRowsPerPage()}
                page={setPageIndex()}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                style={{ float: "left", marginBottom: "10px", marginTop: "48px", marginLeft: "10px" }}
                labelRowsPerPage={
                    <Typography
                        extra_color="tertiary"
                        id="labelRows" style={{ marginTop: "10px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px", color: "#1474A4" }}>
                        {LABEL.ENTRIES_PER_PAGE}
                    </Typography>
                }
                labelDisplayedRows={({ from, to, count }) => (
                    <Typography
                        className={'labelDisplayedRows'}
                        extra_color="tertiary"
                        id="labelDisplayRows" style={{ marginTop: "10px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontSize: "16px", color: "#1474A4" }}>
                        {LABEL.SHOWING}
                        {` ${from}-${to} of ${count}`}
                    </Typography>
                )}
                SelectProps={{ MenuProps: MenuProps }}
                backIconButtonProps={{ disableRipple: true }}
                nextIconButtonProps={{ disableRipple: true }}
            />
        </Paper>
    );
};