/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      DivyaShree U M
 * Date:        17/05/2023 11:00:00 AM
 *
 **/
import jwt_decode from "jwt-decode";
import { getEndTimeValue, getStartDate, getEndDate, clearSessionCache, setSessionErrorMessage, updateSessionToken, updateSessionIdleTime, getSessionTimeDiff } from './util';

describe('Utility coverage', () => {
	const token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZjI2YTlmYy1iYzdmLTRmMmUtODE1NC0yNTUyMjZlNzFjNmIiLCJ1c2VyX2VtYWlsIjoiaGFyc2hhLmJhQHBoaWxpcHMuY29tIiwibmJmIjoxNjg0MTkwMzEwLCJ1c2VyX2lkIjoiYWYyNmE5ZmMtYmM3Zi00ZjJlLTgxNTQtMjU1MjI2ZTcxYzZiIiwidXNlcl9naXZlbl9uYW1lIjoiSGFyc2hhIiwiZXhwIjoxNjg0MTkxMjEwLCJpYXQiOjE2ODQxOTAzMTAsInVzZXJfZmFtaWx5X25hbWUiOiJCQSIsInVzZXJfb3JnYW5pemF0aW9ucyI6eyJtYW5hZ2luZ09yZ2FuaXphdGlvbiI6IjdkZGExMDEzLWM0NjctNDAyNS05NmYyLTZjNjM1M2M0NGE2NyIsIm9yZ2FuaXphdGlvbkxpc3QiOlt7Im9yZ2FuaXphdGlvbklkIjoiN2RkYTEwMTMtYzQ2Ny00MDI1LTk2ZjItNmM2MzUzYzQ0YTY3Iiwib3JnYW5pemF0aW9uTmFtZSI6IkZvY3VzUG9pbnRDbG91ZElvdCIsInBlcm1pc3Npb25zIjpbXSwiZ3JvdXBzIjpbXSwicm9sZXMiOltdfV19fQ.abWJ9WKH4-pIWAqCx-FsBvJy_4dHhZ1YYvkNrLkgUlU';
	const decodedToken: any = jwt_decode(token);

	it('getEndTimeValue', () => {
		const expectedEndTime = '2023-05-17T12:11:20';
		const statusInfo = { date: '2023-05-17T11:11:20', status: 'UP' };
		const actualEndTime = getEndTimeValue(statusInfo);
		expect(actualEndTime).toEqual(expectedEndTime);
	});

	it('getStartDate ', () => {
		const expectedStartDate = '2023-05-16T00:00:00Z';
		const date = '2023-05-17T11:11:20';
		const actualStartDate = getStartDate(date);
		expect(expectedStartDate).toEqual(actualStartDate);
	});


	it('getEndDate function', () => {
		const expectedEndDate = '2023-05-17T00:00:00Z';
		const date = '2023-05-17T11:11:20';
		const actualEndDate = getEndDate(date);
		expect(expectedEndDate).toEqual(actualEndDate);
	});

	it('updateSessionToken ', () => {
		const expectedSessionRenewTime = '1684191210';
		updateSessionToken(token);
		expect(sessionStorage.getItem('sessionToken')).toEqual(token);
		expect(localStorage.getItem('sessionRenewTime')).toEqual(expectedSessionRenewTime);
	});

	it('updateSessionIdleTime ', () => {
		const expectedSessionIdleTime = '1684191210';
		const currentTimeSecondsInEpoch = Math.round(new Date().getTime() / 1000);
		const idleTimeoutDuration = decodedToken.exp - currentTimeSecondsInEpoch;
		updateSessionIdleTime(idleTimeoutDuration);
		expect(localStorage.getItem('sessionIdleTime')).toEqual(expectedSessionIdleTime);
	});

	it('clearSessionCache', () => {
		const expectedTime = '1684191210';
		const currentTimeSecondsInEpoch = Math.round(new Date().getTime() / 1000);
		const idleTimeoutDuration = decodedToken.exp - currentTimeSecondsInEpoch;
		updateSessionIdleTime(idleTimeoutDuration);

		const sessionIdleTime = currentTimeSecondsInEpoch + idleTimeoutDuration;
		localStorage.setItem('sessionIdleTime', sessionIdleTime.toString());
		localStorage.setItem('sessionIdleTimeDuration', idleTimeoutDuration.toString());
		localStorage.setItem('sessionLoggedIn', 'true');
		localStorage.setItem('sessionUserName', 'user');

		expect(localStorage.getItem('sessionIdleTime')).toEqual(expectedTime);
		expect(localStorage.getItem('sessionRenewTime')).toEqual(expectedTime);

		clearSessionCache();

		expect(localStorage.getItem('sessionRenewTime')).toEqual(null);
		expect(localStorage.getItem('sessionIdleTime')).toEqual(null);
		expect(localStorage.getItem('sessionLoggedIn')).toEqual(null);
		expect(localStorage.getItem('sessionUserName')).toEqual(null);
		expect(localStorage.getItem('sessionIdleTimeDuration')).toEqual(null);
	});

	it('setSessionErrorMessage', () => {
		const errorMessage = 'Error Message';
		setSessionErrorMessage(errorMessage);
		expect(localStorage.getItem('sessionErrorMessage')).toEqual(errorMessage);
	});

	it('getSessionTimeDiff', () => {
		const currentTimeSecondsInEpoch = Math.round(new Date().getTime() / 1000);
		const idleTimeoutDuration = decodedToken.exp - currentTimeSecondsInEpoch;
		updateSessionIdleTime(idleTimeoutDuration);
		expect(getSessionTimeDiff('sessionIdleTime')).toBeLessThan(0);
	});

});
