/* eslint-disable @typescript-eslint/no-explicit-any */

import moment from "moment";
import { StatusInfo } from "../../../store/types";
import jwt_decode from "jwt-decode";

export function getEndTimeValue(statusItem: StatusInfo) {
	const time = moment(statusItem.date).format('HH');
	const hr = parseInt(time) + 1;
	let hour = '';
	let endtime = '';
	if (hr > 9) {
		hour = hr.toString();
		if (hour === '24') {
			hour = '00';
			endtime = moment(statusItem.date).add(1, "days").format("YYYY-MM-DD") + "T" + hour + ':' + moment(statusItem.date).format('mm:ss');
		} else {
			endtime = moment(statusItem.date).format('YYYY-MM-DD') + "T" + hour + ':' + moment(statusItem.date).format('mm:ss');
		}
	} else {
		hour = '0' + hr.toString();
		endtime = moment(statusItem.date).format('YYYY-MM-DD') + "T" + hour + ':' + moment(statusItem.date).format('mm:ss');
	}
	return endtime;
}

export function getStartDate(selectedDate: string) {
	const startDate = moment(selectedDate).subtract(1, 'days').format('yyyy-MM-DDT00:00:00') + "Z";
	return startDate;
}

export function getEndDate(selectedDate: string) {
	const endDate = moment(selectedDate).format('yyyy-MM-DDT00:00:00') + "Z";
	return endDate;
}

export function updateSessionToken(token: string) {
	sessionStorage.setItem('sessionToken', token);
	const decodedToken: any = jwt_decode(token);
	localStorage.setItem('sessionRenewTime', decodedToken.exp.toString())
}

export function updateSessionIdleTime(idleTimeDuration: number) {
	const currentTimeSecondsInEpoch = Math.round(new Date().getTime() / 1000);
	const updatedIdleTime = currentTimeSecondsInEpoch + idleTimeDuration;
	localStorage.setItem('sessionIdleTime', updatedIdleTime.toString());
}

export function clearSessionCache() {
	localStorage.removeItem('sessionRenewTime');
	localStorage.removeItem('sessionIdleTime');
	localStorage.removeItem('sessionLoggedIn');
	localStorage.removeItem('sessionUserName');
	localStorage.removeItem('sessionIdleTimeDuration');
}

export function setSessionErrorMessage(message: string) {
	localStorage.setItem('sessionErrorMessage', message);
}

export function getSessionTimeDiff(key: string): number {
	return Number.parseInt(localStorage.getItem(key) ?? Number.POSITIVE_INFINITY.toString()) - Math.round(new Date().getTime() / 1000);
}

export const PREFIX = "Table";

export const classes: any = {
	root: `${PREFIX}-root`,
	paper: `${PREFIX}-paper`,
	table: `${PREFIX}-table`,
	visuallyHidden: `${PREFIX}-visuallyHidden`,
	checkbox: `${PREFIX}-checkbox`,
	truncating: `${PREFIX}-truncating`,
};
