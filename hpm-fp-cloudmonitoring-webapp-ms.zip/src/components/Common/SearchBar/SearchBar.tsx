
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import { useEffect, useState } from "react";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import { Input } from "@dls/react-mui-textfield";
import { Divider } from "@dls/react-mui-divider";
import { Icon } from "@dls/react-icon";
import clsx from "clsx";
import "./SearchBar.scss";
import { useDispatch, useSelector } from "react-redux";
import { setList, SetTotalCount, getList, SetPage, SetSearchLicenseName, IsSearch, SetTenantPage, SetTenantTotalCount, TenantStatusList, SearchResultStatus, setApplicationList, setApplicationName, SetTenantId, SetTenantNameList, ShowTenantSearchResult, SetPreferenceId, SetChecked, SetUserTotalCount, SetUserPreferenceList, SetUserPage, SetUserSearchResultStatus, SetSearchApplication, SetSearchTenant, SetLicensePage, SetLicenseTotalCount, SetLicenseData } from "../../../store/actions";
import { environment } from "../../../environment/environment";
import { RootState } from "../../../store/store";
import * as  service from '../../Services/Service';

export const SearchBar = (props: any) => {
  const dispatch = useDispatch();
  const pageSize = useSelector((state: RootState) => state.list.queryPageSize);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [values, setValues] = useState({
    enteredKeyValue: "",
    onChangeValue: "",
  });

  const [valid, setValid] = useState<boolean>(true);
  const CLOUD_HEALTH_STATUS_URL = environment.BASE_URL + '/HealthCheck';
  const TENANT_CONNECTION_URL = environment.BASE_URL + "/HealthCheck/tenantConnectionStatus";
  const tenantPageSize = useSelector((state: RootState) => state.list.pageSize);
  const [onclick, setOnclick] = useState(false);
  const status = useSelector((state: RootState) => state.list.status);
  const [appName, setAppName] = useState('');
  const tenantStatus = useSelector((state: RootState) => state.list.tenantStatus);
  const tenantSort = useSelector((state: RootState) => state.list.tenantSort);
  const userSettingUrl = environment.BASE_URL + '/AlertSettings';
  const userPageSize = useSelector((state: RootState) => state.user.userPageSize);
  const userSort = useSelector((state: RootState) => state.user.userSort);
  const licenseSort = useSelector((state: RootState) => state.license.licenseSort);
  const licensePageSize = useSelector((state: RootState) => state.license.licensePageSize);
  const LICENSE_CONNECTION_URL = environment.BASE_URL + "/InstallBase";

  useEffect(() => {
    const date: Date = new Date();
    const today = date.toISOString().split('.')[0] + "Z";
    setStartDate(today);
    const yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).toISOString().split('.')[0] + "Z";
    setEndDate(yesterday);
  });


  const validateSearchInput = (value: string) => {
    return /^[0-9a-zA-Z(\b)*-_ ]+$/.test(value);
  };
  const handleClick = (e: any) => {
    setValues({ enteredKeyValue: "", onChangeValue: e.target.value });
    setValid(validateSearchInput(e.target.value));
    searchApplication(!status, values.onChangeValue);
    setOnclick(true);
  }

  const handleChange = (e: any) => {
    setValues({ enteredKeyValue: "", onChangeValue: e.target.value });
    setValid(validateSearchInput(e.target.value));
    if (e.key === 'Enter') {
      if (e.target.value.length === 0) {
        setValid(true);
        setErrorMessage('');
      }
      searchApplication(!status, e.target.value);
      setOnclick(true);
    }
  }
  const handleClear = () => {
    setValues({ enteredKeyValue: "", onChangeValue: "" });
    dispatch(ShowTenantSearchResult(true));
    dispatch(IsSearch(false));
    setValid(true);
    setOnclick(false);
    setAppName('');
    setErrorMessage('');
    searchApplication(!status, "");
    if (props.card === "license") {
      const params: any = {
        tenantName: "",
        pageNumber: 1,
        recordsPerPage: licensePageSize,
        sortingOrder: licenseSort
      }
      licenseSearch(params);
    } else if (props.card !== 'tenant') {
      const params: any = {
        daywiseStatus: true,
        start: endDate,
        end: startDate,
        pageNumber: 1,
        recordsPerPage: pageSize,
        applicationName: '',
        sortingOrder: 'asc'
      }
      service.getDetails(CLOUD_HEALTH_STATUS_URL, params).then((response: any) => {
        dispatch(setList(response.data));
        dispatch(SetTotalCount(response.data[0].totalRecords));
        dispatch(setApplicationList(response.data));
        dispatch(setApplicationName(response.data[0].applicationName));
      }).catch(error => {
        setErrorMessage(error.message);
        setValid(true);
        dispatch(SearchResultStatus(true));
      })
    } else {
      const params: any = {
        start: endDate,
        end: startDate,
        tenantName: "",
        pageNumber: 1,
        recordsPerPage: tenantPageSize,
        sortingOrder: tenantSort,
        applicationName: '',
      };
      if (tenantStatus) {
        tenantHistorySearch(params);
      } else {
        tenantDaywiseSearch(params);
      }
    }
  }

  const searchApplication = (daywiseStatus: boolean, searchValue: string) => {
    if (props.card === 'cloud') {
      setAppName(searchValue ?? appName);
      dispatch(SetSearchApplication(searchValue));
      const params: any = {
        daywiseStatus: true,
        start: endDate,
        end: startDate,
        pageNumber: 1,
        recordsPerPage: pageSize,
        applicationName: searchValue,
        sortingOrder: 'asc'
      }
      if (daywiseStatus) {
        cloudDaywiseSearch(params);
      } else {
        cloudHistorySearch(params);
      }
    } else if (props.card === 'tenant') {
      dispatch(SetSearchTenant(searchValue));
      const params: any = {
        start: endDate,
        end: startDate,
        tenantName: searchValue,
        pageNumber: 1,
        recordsPerPage: tenantPageSize,
        sortingOrder: tenantSort
      }

      if (tenantStatus) {
        tenantHistorySearch(params);
      } else {
        tenantDaywiseSearch(params);
      }
    } else if (props.card === "license") {
      const params: any = {
        tenantName: searchValue,
        pageNumber: 1,
        recordsPerPage: licensePageSize,
        sortingOrder: licenseSort
      }
      dispatch(SetSearchLicenseName(searchValue));
      licenseSearch(params);
      setErrorMessage('');
    } else {
      const params: any = {
        pageNumber: 1,
        recordsPerPage: userPageSize,
        sortingOrder: userSort,
        tenantName: searchValue
      };
      service.getUserPreferenceDetails(userSettingUrl, params).then((response: any) => {
        response.data.forEach((element: any) => {
          if (element.subscriptions === null) {
            element.subscriptions = [
              {
                applicationName: "hpm-fp-dataflow",
                subscribed: false
              },
              {
                applicationName: "focal-point-status",
                subscribed: false
              },
              {
                applicationName: "web-socket-client-connection",
                subscribed: false
              },
            ];
          }
          element.subscriptions.forEach((item: any) => {
            if (item.applicationName === "cloud-subscribed") {
              dispatch(SetPreferenceId(element.preferenceId));
              dispatch(SetChecked(item.subscribed));
            }
          });
        });
        dispatch(SetUserTotalCount(response.data[0].totalRecords));
        dispatch(SetUserPreferenceList(response.data));
        dispatch(getList());
        dispatch(IsSearch(true));
        dispatch(SetUserPage(0));
        dispatch(SetUserSearchResultStatus(true));

      }).catch(error => {
        setErrorMessage(error.message);
        dispatch(SetUserSearchResultStatus(false));
        dispatch(SetUserTotalCount(0));
      });
    }
  }
  const cloudDaywiseSearch = (params: any) => {
    service.getDetails(CLOUD_HEALTH_STATUS_URL, params).then((response) => {
      dispatch(setList(response.data));
      dispatch(getList());
      dispatch(IsSearch(true));
      dispatch(SetPage(0));
      dispatch(SetTotalCount(response.data[0].totalRecords));
      dispatch(setApplicationName(response.data[0].applicationName));
      dispatch(SearchResultStatus(true));
      setErrorMessage('');
    }).catch((error) => {
      setErrorMessage(error.message);
      dispatch(SearchResultStatus(false));
      dispatch(SetTotalCount(0));
      dispatch(setList([]));
    });
  }
  const cloudHistorySearch = (params: any) => {
    service.getDetails(CLOUD_HEALTH_STATUS_URL, params).then((response: any) => {
      dispatch(setApplicationList(response.data));
      dispatch(setApplicationName(response.data[0].applicationName));
      dispatch(setList(response.data));
      dispatch(getList());
      dispatch(IsSearch(true));
      dispatch(SetPage(0));
      dispatch(SetTotalCount(response.data[0].totalRecords));
      dispatch(SearchResultStatus(true));
      setErrorMessage('');
    }).catch(error => {
      setErrorMessage(error.message);
      dispatch(SearchResultStatus(false));
      dispatch(SetTotalCount(0));
      dispatch(setApplicationList([]));
    });
  }
  const setTenantList = (response: any) => {
    dispatch(getList());
    dispatch(IsSearch(true));
    dispatch(SetTenantPage(0));
    dispatch(SetTenantTotalCount(response.data[0].totalRecords));
    setErrorMessage('');
  }
  const tenantDaywiseSearch = (params: any) => {
    service.getDetails(TENANT_CONNECTION_URL, params).then((response: any) => {
      dispatch(TenantStatusList(response.data));
      setTenantList(response);
    }).catch(error => {
      setErrorMessage(error.message);
      dispatch(SetTenantTotalCount(0));
      dispatch(TenantStatusList([]));
    });
  }
  const tenantHistorySearch = (params: any) => {
    service.getDetails(TENANT_CONNECTION_URL, params).then((response: any) => {
      dispatch(SetTenantNameList(response.data));
      dispatch(SetTenantId(response.data[0].tenantId));
      dispatch(ShowTenantSearchResult(true));
      setTenantList(response);
    }).catch(error => {
      setErrorMessage(error.message);
      dispatch(ShowTenantSearchResult(false));
      dispatch(SetTenantTotalCount(0));
      dispatch(TenantStatusList([]));
    });
  }

  const licenseSearch = (params: any) => {
    service.licenseDetails(LICENSE_CONNECTION_URL, params).then((response: any) => {
      dispatch(SetLicenseData(response.data.data));
      dispatch(SetLicenseTotalCount(response.data.totalRecords));
      dispatch(IsSearch(true));
      dispatch(SetLicensePage(0));
    }).catch(error => {
      setErrorMessage(error.message);
    });
  }
  return (
    <div className="customSearchBox">
      <Input
        id="adornment-searchbox-custom-width"
        type={"text"}
        className={clsx("DLS-SearchBox")}
        value={values.onChangeValue}
        onChange={handleChange}
        placeholder={props.card === 'userPreference' || props.card === 'tenant' ? "Tenant Name" : props.card === "license" ? "Search Customer Name" : "Search Services"}
        autoComplete="off"
        onKeyDown={handleChange}
        required
        endAdornment={
          <InputAdornment position="end">
            <div>
              <IconButton
                onClick={handleClear}
              >
                {values.onChangeValue || onclick ? (
                  <Icon name={"CrossCircle"} size={"m"} />
                ) : null}
              </IconButton>
            </div>
            <div>
              {values.onChangeValue || onclick ? (
                <Divider
                  orientation="vertical"
                  className={"DLS-divider-vertical"}
                  flexItem
                />
              ) : null}
            </div>
            <div>
              <IconButton onClick={handleClick}>
                <Icon name={"Search"} size={"m"} style={{ cursor: "pointer" }} />
              </IconButton>
            </div>
          </InputAdornment>
        }
        fullWidth
      />

      {!valid && (
        <span className="validation-error">
          {<Icon name="InformationCircleOutline" size={"s"} />}
          {"Search value is not valid"}
        </span>
      )}
      {errorMessage.length !== 0 && props.card === 'cloud' && (
        <span className="validation-error">
          {<Icon name="InformationCircleOutline" size={"s"} />}
          {"Application name is not found"}
        </span>
      )}
      {errorMessage.length !== 0 && props.card === 'userPreference' && (
        <span className="validation-error">
          {<Icon name="InformationCircleOutline" size={"s"} />}
          {"Tenant name is not found"}
        </span>
      )}
      {errorMessage.length !== 0 && props.card === 'tenant' && (
        <span className="validation-error">
          {<Icon name="InformationCircleOutline" size={"s"} />}
          {"Tenant name is not found"}
        </span>
      )}
      {errorMessage.length !== 0 && props.card === 'license' && (
        <span className="validation-error">
          {<Icon name="InformationCircleOutline" size={"s"} />}
          {"Customer name is not found"}
        </span>
      )}
    </div>
  );
};