/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2023 10:00:00 AM
 *
 **/

export const LABEL = {
    LABEL_TENANT_CONNECTION_STATUS: 'Tenant Connection Status',
    LABEL_CLOUD_HEALTH_STATUS: 'Cloud Health Status',
    NO_DATA_AVAILABLE: 'No Data Available',
    ENTRIES_PER_PAGE: 'Entries per page:',
    SHOWING: 'Showing',
    FROM: 'From',
    TO: 'To',
    DURATION: 'Duration',
    LABEL_DOWN_TIME_DETAILS: 'DownTime Details for hour',
    LABEL_NO_DOWN_TIME: 'There is No DownTime for hour',
    LABEL_DISCLAIMER: '*Please select an hour bar to see the hourly connection details below',
    LABEL_HOUR_CONNECTION_DETAILS: 'Hourly connection details-',
    LABEL_24HOUR_DETAILS: '24 hours connection details-',
    LABEL_SELECTED_DATE: 'Selected Date',
    LABEL_NO_STATUS: 'No Status is Available',
    HEALTHY: 'Healthy',
    NEEDS_ATTENTION: 'Needs Attention',
    NO_RECORDS: 'No Records',
    NO_STATUS_AVAILABLE: 'No Status Available',
    INSTALL_BASE_SUMMARY: 'Install Base Summary',
    SEARCH_CUSTOMER_NAME: 'Search Customer Name',
    CUSTOMER_NAME_IS_NOT_FOUND: 'Customer name is not found',
    DOWNLOAD_SUMMARY: 'Download Summary',
    UNABLE_TO_DOWNLOAD_THE_REPORT_PLEASE_TRY_AFTER_SOMETIME: 'Unable to download the report, please try after sometime',
    HISTORY_VIEW: 'History View'
}

export const headers = [
    { label: "Customer Name", key: "tenantName" },
    { label: "License Type", key: "licenseType" },
    { label: "Product Version", key: "productVersion" },
    { label: "PIC licenced bed", key: "bedDetails" },
    { label: "Activation Date", key: "activationDate" }
]

export const licenseDataColumns = [
    {
        Header: 'Customer Name',
        accessor: 'tenantName', // accessor is the "key" in the data
        disableSortBy: true
    },
    {
        Header: 'License Type',
        accessor: 'licenseType',
        disableSortBy: true
    },
    {
        Header: 'Product Version',
        accessor: 'productVersion',
        disableSortBy: true
    },
    {
        Header: 'PICiX Used Beds',
        accessor: 'bedDetails',
        disableSortBy: true
    },
    {
        Header: 'Activation Date',
        accessor: 'activationDate',
        disableSortBy: true
    },
];

