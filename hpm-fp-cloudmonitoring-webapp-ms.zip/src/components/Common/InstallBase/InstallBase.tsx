/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      divyashree
 * Date:        18/08/2023 10:00:00 AM
 **/

import { Card, Container, Typography } from "@dls/react-core";
import { useSelector } from "react-redux";
import { RootState } from "../../../store/store";
import Navbar from "../Navbar/Navbar";
import { SearchBar } from "../SearchBar/SearchBar";
import { Pagination } from "../Pagination/Pagination";
import { InstallBaseTable } from "../InstallBaseTable/InstallBaseTable";
import DownloadSummary from "../../DownloadSummary/DownloadSummary";
import "./InstallBase.scss";
import { LABEL } from "../constants";
import { Col } from "react-bootstrap";

export const InstallBase = () => {
    const licenseList = useSelector((state: RootState) => state.license.licenseList);

    return (
        <div>
            <Container >
                <div className="Navbar_license">
                    <Navbar></Navbar>
                </div>
                <div>
                    <Card style={{ marginTop: "49px", width: "1190px", marginBottom: "20px", opacity: "100%" }}>
                        <div>
                            <Typography variant="h6" style={{ marginTop: "10px", marginLeft: "10px", fontSize: "20px", fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif", fontWeight: "500", marginRight: "" }}>{LABEL.INSTALL_BASE_SUMMARY}
                            </Typography>
                            <div className="row">
                                <Col md={10} style={{ width: "75%", marginLeft: "10px" }}>
                                    <SearchBar placeholder={LABEL.SEARCH_CUSTOMER_NAME} card="license"></SearchBar>
                                </Col>
                                <Col md={2}>
                                    <DownloadSummary></DownloadSummary>
                                </Col>
                            </div>
                            <div id="InstallBaseTable_license">
                                <div className="InstallBaseTable">
                                    <InstallBaseTable tabledata={licenseList}></InstallBaseTable>
                                </div>
                            </div>
                            <div id="Pagination_license">
                                <div className="Pagination">
                                    <Pagination card="license"></Pagination>
                                </div>
                            </div>
                        </div>
                    </Card>
                </div >
            </Container>
        </div>

    );
};

