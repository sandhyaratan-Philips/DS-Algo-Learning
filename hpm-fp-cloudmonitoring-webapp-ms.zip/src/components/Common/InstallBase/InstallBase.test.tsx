
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      DivyaShree U M
 * Date:        23/08/2023 11:00:00 AM
 *
 **/

import React from "react";
import { render, screen } from "@testing-library/react";
import { Provider } from 'react-redux';
import store from "../../../store/store";
import { SearchBar } from "../SearchBar/SearchBar";
import { Pagination } from "../Pagination/Pagination";
import { InstallBase } from "./InstallBase";


describe("InstallBase component to be present in ui", () => {
    const mockDispatch = jest.fn();

    jest.mock('react-redux', () => ({
        useSelector: jest.fn(),
        useDispatch: () => mockDispatch
    }));

    it('InstallBase  to be in the document', () => {
        renderWithContext(<InstallBase />);
        expect(screen.getByTestId("InstallBase")).toBeInTheDocument;
    });

    function renderWithContext(element: React.ReactElement) {
        render(
            <Provider store={store}>{element}</Provider>
        )
    }
    it("checking the Card title to be searchbar", () => {
        setTimeout(() => {
            expect(SearchBar).toBeInTheDocument();
        }, 5000)
    });

    it("checking the Card title to be pagination", () => {
        setTimeout(() => {
            expect(Pagination).toBeInTheDocument();
        }, 5000)

    });
});
