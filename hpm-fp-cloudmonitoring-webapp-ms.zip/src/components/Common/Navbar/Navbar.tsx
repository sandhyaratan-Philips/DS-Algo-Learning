/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import React from "react";
import { Divider } from "@dls/react-mui-divider";
import { Toolbar } from "@dls/react-mui-toolbar";
import { Icon } from "@dls/react-icon";
import { Typography } from "@dls/react-mui-typography";
import { UserInfoMenu } from "../UserInfo/UserInfoMenu";
import { useNavigate } from 'react-router-dom';

export const Navbar: React.FC<Record<string, unknown>> = () => {
	const navigate = useNavigate();
	const navigateToSettings = () => {
		navigate('/settings');
	}
	const navigateToDashboard = () => {
		navigate('/dashboard');
	}
	const navigateToInstallBase = () => {
		navigate('/InstallBase');
	}
	return (
		<>
			<Toolbar
				className={"dls-toolbar-container"}
				style={{
					height: "56px",
					backgroundColor: "#2B86B2",
					color: "#FFFFFF",
					padding: "0.2rem",
					fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif",
					fontSize: "20px",
					lineHeight: "37px",
					font: "500",
				}}
			>
				<>
					<Typography
						variant="h3"
						weight="weight-700"
						style={{
							paddingLeft: 24,
							paddingRight: 24,
							marginTop: "20px",
							textAlign: "center",
							display: "flex",
							flexDirection: "column",
							fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif",
							fontSize: "20px",
							color: "#FFFFFF",
							lineHeight: "14px",
							opacity: "15px",
							whiteSpace: "nowrap",
						}}
					>
						<p
							style={{
								marginBottom: "2px",
								marginTop: "4px",
								marginLeft: "4px",
								fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif",
								fontWeight: "500",
								padding: "0.3px",
								fontSize: "20px",
								whiteSpace: "nowrap",
								width: "120px",
								lineHeight: "28px",
								alignItems: "center",
								color: "#FFFFFF",
							}}
						>
							Focal Point{" "}
						</p>
						<span
							style={{
								fontSize: "10px",
								lineHeight: "2px",
								fontWeight: "700",
								fontFamily: "CentraleSansCondensedBold, Helvetica, Arial, Verdana, Tahoma, sans-serif",
								color: "#FFFFFF",
								width: "109px",
								height: "15px",
								marginTop: "2px",
								textAlign: "center",
								marginLeft: "10px",
							}}
						>
							Cloud Monitoring Systems
						</span>
					</Typography>
					<Typography
						variant="h5"
						weight="weight-400"
						onClick={navigateToDashboard}
						style={{
							marginBottom: 0,
							width: "140px",
							textAlign: "center",
							lineHeight: "65px",
							fontWeight: "500",
							padding: "0.5px",
							color: "#FFFFFF",
							opacity: "100%",
							fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif",
							fontSize: "16px",
							border: "none",
							textDecoration: "none",
							display: "inline-block",
							margin: "7px 3px",
							height: "60px",
							cursor: "pointer"
						}}
					>
						Dashboard
					</Typography>
					<Typography
						variant="h5"
						weight="weight-400"
						onClick={navigateToSettings}
						style={{
							marginBottom: 0,
							width: "140px",
							textAlign: "center",
							lineHeight: "65px",
							fontWeight: "500",
							padding: "0.5px",
							color: "#FFFFFF",
							opacity: "100%",
							fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif",
							fontSize: "16px",
							border: "none",
							textDecoration: "none",
							display: "inline-block",
							margin: "7px 3px",
							height: "60px",
							cursor: "pointer"
						}}
					>
						Settings
					</Typography>
					<Typography
						variant="h5"
						weight="weight-400"
						onClick={navigateToInstallBase}
						style={{
							marginBottom: 0,
							width: "140px",
							textAlign: "center",
							lineHeight: "65px",
							fontWeight: "500",
							padding: "0.5px",
							color: "#FFFFFF",
							opacity: "100%",
							fontFamily: "CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif",
							fontSize: "16px",
							border: "none",
							textDecoration: "none",
							display: "inline-block",
							margin: "7px 3px",
							height: "60px",
							cursor: "pointer"
						}}
					>
						Install Base
					</Typography>
				</>

				<span
					style={{
						marginLeft: "auto",
						width: "2rem",
						alignItems: "end",
						padding: "0.2rem",
						wordSpacing: "0px 10px",
						alignContent: "center",
						height: "4rem",
					}}
				>
					<Icon name="InformationCircleOutline" size={"m"} />
				</span>

				<Divider
					orientation="vertical"
					className={"DLS-divider-vertical"}
					style={{ opacity: "100%", width: "1px", height: "24px" }}
				/>
				<UserInfoMenu />
			</Toolbar>
		</>
	);
};
export default Navbar;
