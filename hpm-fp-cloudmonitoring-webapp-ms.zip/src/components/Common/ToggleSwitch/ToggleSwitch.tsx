/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import React, { useEffect } from "react";
import { Switch } from "@dls/react-mui-switch";
import { useDispatch } from "react-redux";
import { getList, setToggleHistoryView, SetToggleTenantHistoryView } from "../../../store/actions";
import { LABEL } from "../constants";

export const ToggleSwitch = (props: any) => {
  const dispatch = useDispatch();
  const [checked, setChecked] = React.useState(false);
  const [toggleOn, setToggleOn] = React.useState(false);

  useEffect(() => {
    getList();
  }, []);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (props.card !== 'tenant') {
      setChecked(event.target.checked);
      dispatch(setToggleHistoryView(event.target.checked));
    } else {
      setToggleOn(event.target.checked);
      dispatch(SetToggleTenantHistoryView(event.target.checked));
    }
  }

  return (
    <span
      style={{
        fontFamily: "CentraleSansMedium,Helvetica, Arial, Verdana, Tahoma, sans-serif",
        fontSize: "15px",
        color: "#1474A4",
        textAlign: "left",
        lineHeight: "22px",
        fontWeight: "400",
        alignItems: "center",
        opacity: "100%",
      }}
    >
      <span> {LABEL.HISTORY_VIEW}</span>
      <Switch
        checked={props.card !== 'tenant' ? checked : toggleOn}
        onChange={handleChange}
        style={{ float: "right" }}
        name="checkedA"
      />
    </span>
  );
};
