/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Harsha B A
 * Date:        28/03/2023 03:00:00 PM
 *
 **/

import React, { useEffect, useState } from 'react';

import {
	Menu,
	MenuItem
} from '@dls/react-mui-menu';
import { Label } from '@dls/react-mui-typography';
import { Icon } from '@dls/react-icon';
import './UserInfoMenu.scss'
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { clearSessionCache } from '../util/util';
import { logoutUser } from '../../Services/SessionService';
import { environment } from '../../../environment/environment';
import { resetLicenseState, resetListState, resetUserState } from '../../../store/actions';


export const UserInfoMenu = () => {
	const options = ['Profile', 'Logout'];
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const [anchorEl, setAnchorEl] = useState(null);
	const [selectedIndex, setSelectedIndex] = useState(0);
	const [selectedItem, setSelectedItem] = useState('');

	useEffect(() => {
		if (selectedItem === options[1]) {
			logoutUser(`${environment.BASE_URL}/logoutCloudUser`);
			dispatch(resetLicenseState());
			dispatch(resetUserState());
			dispatch(resetListState());
			clearSessionCache();
			localStorage.setItem('sessionErrorMessage', '');
			navigate('/');
		}
	}, [selectedItem]);

	const handleMenuItemClick = (
		_event: React.MouseEvent<HTMLElement>,
		index: number,
	) => {
		setSelectedIndex(index);
		setSelectedItem(options[index]);
		setAnchorEl(null);
	};

	const handleClick = (event: any) => {
		setAnchorEl(event.currentTarget);
	};

	const handleClose = () => {
		setAnchorEl(null);
	};

	return (
		<div>
			<div style={{
				display: 'flex',
				cursor: 'pointer',
				marginBottom: '0.1rem'
			}}
				onClick={handleClick}>
				<Icon name="PersonPortraitCircle" />
				<div style={{
					fontWeight: '500',
					fontSize: '1rem',
					fontFamily: 'CentraleSansMedium, Helvetica, Arial, Verdana, Tahoma, sans-serif',
					color: '#FFFFFF',
					marginTop: '0.7rem',
					marginLeft: '0.5rem',
					lineHeight: '1rem',
					textAlign: 'center'
				}}>
					{localStorage.getItem('sessionUserName')} </div>
				<div>
					<Icon style={{
						marginBottom: '1.5rem',
						marginLeft: '0.3rem'
					}} name='ArrowDown' size={'s'} />
				</div>
			</div>
			<Menu
				style={{
					marginTop: '1.4rem'
				}}
				anchorEl={anchorEl}
				open={Boolean(anchorEl)}
				onClose={handleClose}
				anchorOrigin={{
					vertical: 'bottom',
					horizontal: 'center',
				}}
				transformOrigin={{
					vertical: 'top',
					horizontal: 'center',
				}}
				PaperProps={{
					className: 'DLSMenuList',
				}}>
				{options.map((option, index) => (
					<MenuItem style={{ minWidth: '8rem' }}
						key={option}
						selected={index === selectedIndex}
						onClick={(event: any) => handleMenuItemClick(event, index)}>
						<Label label_variant='value'>{option}</Label>
					</MenuItem>
				))}
			</Menu>

		</div>
	);
};
