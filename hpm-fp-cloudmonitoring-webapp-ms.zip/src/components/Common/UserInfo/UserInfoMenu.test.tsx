/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Harsha B A
 * Date:        18/05/2023 11:00:00 AM
 *
 **/

import Enzyme, { ShallowWrapper} from 'enzyme';
import { UserInfoMenu } from './UserInfoMenu';
import Adapter from '@cfaester/enzyme-adapter-react-18';
import {
	Menu, MenuItem
} from '@dls/react-mui-menu';

jest.mock('react-router-dom', () => ({
	...jest.requireActual('react-router-dom'),
	useNavigate: () => jest.fn()
}));

jest.mock('@dls/react-mui-menu');
Enzyme.configure({ adapter: new Adapter() });

describe('UserInfoMenu Coverage', () => {
	const component =  new ShallowWrapper(<UserInfoMenu/>);
	const mockEvent = { currentTarget: jest.fn(), preventDefault: jest.fn() };
	it('handle click', () => {
		const handleClickFunc = component.find('div').get(1).props?.onClick;
		jest.mock(handleClickFunc);
		handleClickFunc(mockEvent);
		expect(handleClickFunc(mockEvent)).toBeUndefined();
	});

	it('handle close', () => {
		const handleCloseFunc = component.find(Menu).get(0).props?.onClose;
		jest.mock(handleCloseFunc);
		handleCloseFunc();
		expect(handleCloseFunc()).toBeUndefined();
	});

	it('handleMenuItemClick', () => {
		const handleMenuItemClickFunc = component.find(MenuItem).get(0).props?.onClick;
		jest.mock(handleMenuItemClickFunc);
		handleMenuItemClickFunc(mockEvent, 0);
		expect(handleMenuItemClickFunc(mockEvent, 0)).toBeUndefined();
	});
});