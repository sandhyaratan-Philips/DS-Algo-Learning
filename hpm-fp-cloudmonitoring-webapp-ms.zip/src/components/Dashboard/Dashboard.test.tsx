/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import store from '../../store/store';
import Dashboard from './Dashboard';
import './Dashboard.scss';
import axios from 'axios';
import response from '../../mock/cloudApplicationListResponse.json';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;
describe('Dashboard component', () => {
  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));

  it('bar-graph  to be in the document', () => {
    renderWithContext(<Dashboard />);

  });
  it('renders response from api response', () => {
    renderWithContext(<Dashboard />);
    const mockedResponse: any = {
      data: response,
      status: 200,
      statusText: 'OK',
      headers: {},
      config: {},

    };
    mockedAxios.get.mockResolvedValue(mockedResponse);
    renderWithContext(<Dashboard />);
    expect(axios.get).toHaveBeenCalled();

  });

  it("checking the Card title to be Tenant Connection Status", () => {

    setTimeout(() => {
      const tenantCard = screen.getByTestId("Card-title");
      expect(tenantCard).toBeInTheDocument();
    }, 5000)

  });
  it("Checking the Card title to be Cloud Health Status", () => {

    setTimeout(() => {
      const healthcard = screen.getByTestId("Cloud-title");
      expect(healthcard).toBeInTheDocument();
    }, 5000)

  });
  it("checking the main layout of card to be present", () => {
    setTimeout(() => {
      const card = screen.getByTestId("card");
      expect(card).toBeInTheDocument();
    }, 5000)

  });
  it("pagination to be in tenant card", () => {
    setTimeout(() => {
      const pagination = screen.getByTestId("pagination");
      expect(pagination).toBeInTheDocument();
    }, 5000)

  });

  function renderWithContext(element: React.ReactElement) {
    render(
      <Provider store={store}>{element}</Provider>
    )
  }

});
