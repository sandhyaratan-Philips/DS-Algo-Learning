/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import * as React from "react";
import "./Dashboard.scss";
import ListDetails from "../List/ListDetails";
import { Card } from "@mui/material";
import { Row } from "react-bootstrap";
import { Col } from "react-bootstrap";
import Alert from "react-bootstrap/Alert";
import Spinner from "react-bootstrap/Spinner";
import { SearchBar } from "../Common/SearchBar/SearchBar";
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { setList, SetTotalCount } from '../../store/actions';
import DayWiseStatus from "../DayWiseStatus/DayWiseStatus";
import { LABEL } from "../Common/constants";
import { RootState } from "../../store/store";
import HistoryView from "../HistoryView/HistoryView";
import { ToggleSwitch } from "../Common/ToggleSwitch/ToggleSwitch";
import { environment } from "../../environment/environment";
import moment from "moment";
import { Pagination } from "../Common/Pagination/Pagination";
import { CollapsibleTable } from "../CollapsibleTable/CollapsibleTable";
import Container from 'react-bootstrap/Container';
import TenantHistoryView from "../TenantHistoryView/TenantHistoryView";

const Dashboard: React.FunctionComponent<Record<string, unknown>> = () => {
	const dispatch = useDispatch();
	const pageIndex = useSelector((state: RootState) => state.list.queryPageIndex);
	const pageSize = useSelector((state: RootState) => state.list.queryPageSize);
	const status = useSelector((state: RootState) => state.list.status);
	const sort = useSelector((state: RootState) => state.list.sort);

	const [data, setData] = useState();
	const [loading, setLoading] = useState(true);
	const [errorMessage, setErrorMessage] = useState('');
	const [selectedDate, setSelectedDate] = useState<string>();
	const cardName = 'tenant';
	const card = 'cloud';
	const CLOUD_HEALTH_STATUS_URL = environment.BASE_URL + '/HealthCheck';
	const tenantStatus = useSelector((state: RootState) => state.list.tenantStatus);

	useEffect(() => {
		getData();
	}, [status]);

	const getData = async () => {
		const date: Date = new Date();
		const today = date.toISOString().split('.')[0] + "Z";
		const yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).toISOString().split('.')[0] + "Z";
		const currentDate = moment(date).format('DD') + ' ' + moment(date).format('MMM, YYYY');
		setSelectedDate(currentDate);
		try {
			const response = await axios.get(CLOUD_HEALTH_STATUS_URL, {
				params: {
					daywiseStatus: true,
					start: yesterday,
					end: today,
					pageNumber: pageIndex + 1,
					recordsPerPage: pageSize,
					applicationName: '',
					sortingOrder: sort
				}, headers: {
					Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
				}
			});
			setData(response.data);
			dispatch(setList(response.data));
			dispatch(SetTotalCount(response.data[0].totalRecords));

		} catch (error) {
			setErrorMessage("Data is null");
		}
		finally {
			setLoading(false);
		}
	}

	if (loading)
		return (
			<div className="spinner-style" data-testid="loading">
				<Spinner animation="border" variant="dark" />
			</div>
		);
	if (errorMessage)
		return (
			<div data-testid="titleTenant">
				<Alert>{errorMessage}</Alert>
			</div>
		);
	if (!data)
		return (
			<div className="null-alert">
				<Alert variant="danger">Data is Null</Alert>
			</div>
		);

	return (
		<Container className="container-style">
			<Card
				variant="outlined"
				data-testid="CloudHealth-card"
				className="card-tenant-health"
			>
				<div className="title-align">
					<span className="card-title" data-testid="Tenant-title">
						{LABEL.LABEL_TENANT_CONNECTION_STATUS}
					</span>
					<span className="dateDispaly">
						<span className="dateLabel" data-testid="datelabel">
							Today, {selectedDate}
						</span>
						<span className="toggleSwitch">
							<ToggleSwitch card={cardName}></ToggleSwitch>
						</span>
					</span>
					<div className="searchBar">
						<SearchBar card={cardName}></SearchBar>
					</div>
				</div>
				<Row className="collapsibleTable">
					<Col><div>{tenantStatus ? <TenantHistoryView></TenantHistoryView> : <CollapsibleTable></CollapsibleTable>}</div></Col>
				</Row>
				<Row className="pagination" data-testid="pagination">
					<Pagination card={cardName}></Pagination>
				</Row>
			</Card>

			<Card
				variant="outlined"
				data-testid="CloudHealth-card"
				className="card-cloudhealth"
			>
				<div className="title-align">
					<span className="card-title" data-testid="Cloud-title">
						{LABEL.LABEL_CLOUD_HEALTH_STATUS}
					</span>
					<span className="dateDispaly">
						<span className="dateLabel" data-testid="datelabel">
							Today, {selectedDate}
						</span>
						<span className="toggleSwitch">
							<ToggleSwitch card={card}></ToggleSwitch>
						</span>
					</span>
				</div>
				<div className="searchBar">
					<SearchBar card={card}></SearchBar>
				</div>
				<Row className="row-container">
					<Col md={4}>
						<div>
							{data ? (
								<ListDetails></ListDetails>
							) : (
								<div>{LABEL.NO_DATA_AVAILABLE}</div>
							)}
						</div>
					</Col>
					<Col md={8} className="midPannel">
						<div>
							{status ? <HistoryView></HistoryView> : <DayWiseStatus></DayWiseStatus>
							}
						</div>
					</Col>
				</Row>
				<Row>
					<Pagination card={card}></Pagination>
				</Row>
			</Card>
		</Container>
	);
};
export default Dashboard;
