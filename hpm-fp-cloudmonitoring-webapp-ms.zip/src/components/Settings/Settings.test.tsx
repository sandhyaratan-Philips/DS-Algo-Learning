/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        19/05/2023 11:00:00 AM
 *
 **/
import Settings from './Settings';
import Enzyme, { ShallowWrapper } from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';

Enzyme.configure({ adapter: new Adapter() });

describe("Settings component to be present in ui", () => {
  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));
  jest.mock('react-i18next', () => ({
    ...jest.requireActual('react-i18next'),
    useTranslation: () => {
      return {
        t: (str: string) => str,
        i18n: {
          language: 'en'
        },
      };
    },
  }));

  it("settings component to be in the document", () => {
    const settingComponent = new ShallowWrapper(<Settings />);
    const set = settingComponent.find('div');
    expect(set).toBeTruthy();
  });
  it("Container component to be in the document", () => {
    const settingComponent = new ShallowWrapper(<Settings />);
    const container = settingComponent.find('Container');
    expect(container).toBeTruthy();

  });
  it("Card component to be in the document", () => {
    const settingComponent = new ShallowWrapper(<Settings />);
    const card = settingComponent.find('Card');
    expect(card).toBeTruthy();

  });
  it("Row component to be in the document", () => {
    const settingComponent = new ShallowWrapper(<Settings />);
    const row = settingComponent.find('Row');
    expect(row).toBeTruthy();

  });
  it("Col component to be in the document", () => {
    const settingComponent = new ShallowWrapper(<Settings />);
    const col = settingComponent.find('Col');
    expect(col).toBeTruthy();

  });
});

