/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        18/05/2023 11:00:00 AM
 *
 **/
import { Card } from "@mui/material";
import Container from 'react-bootstrap/Container';
import { Row } from "react-bootstrap";
import { Col } from "react-bootstrap";
import { SearchBar } from "../Common/SearchBar/SearchBar";
import { SettingsTable } from "../SettingsTable/SettingsTable";
import { useTranslation } from 'react-i18next';
import { Pagination } from "../Common/Pagination/Pagination";
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";

const Settings = () => {
	const { t } = useTranslation('translations', { keyPrefix: 'userpreference' });
	const card = "userPreference";
	const userSerachStatus = useSelector((state: RootState) => state.user.userSerachStatus);
	return (
		<div data-testid="userList">
			<Container className="container-style" data-testid='Container'>
				<Card variant="outlined" className="card-tenant-health" data-testid='Card'>
					<div className="title-align">
						<span className="card-title">
							{t('HEADING_TENANT_MAIL_SUBSCRIPTION')}
						</span>
						<div className="searchBarAlignment">
							<SearchBar card={card}></SearchBar>
						</div>
					</div>
					<Row className="collapsibleTable">
                     <div>{userSerachStatus &&
						<Col><SettingsTable></SettingsTable></Col>
					}</div>
					</Row>
					<Row className="pagination">
						<Pagination card={card}></Pagination>
					</Row>
				</Card>
			</Container>
		</div>
	);
};
export default Settings;