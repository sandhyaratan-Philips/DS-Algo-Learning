/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      DivyaShree U M
 * Date:        15/05/2023 11:00:00 AM
 *
 **/

import Login from './Login';
import axios from "axios";
import Enzyme, { ShallowWrapper } from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';
import { LoginPage } from '@dls/react-login-page';
import { validateUserSession, renewSession, logoutUser } from '../Services/SessionService';

jest.mock('react-i18next', () => ({
	...jest.requireActual('react-i18next'),
	useTranslation: () => {
		return {
			t: (str: string) => str,
			i18n: {
				language: 'en'
			},
		};
	},
}));

jest.mock('react-router-dom', () => ({
	...jest.requireActual('react-router-dom'),
	useNavigate: () => jest.fn()
}));

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

Enzyme.configure({ adapter: new Adapter() });

describe('Login component', () => {
	const login = new ShallowWrapper(<Login />);
	const loginPage = login.find(LoginPage);
	const title = loginPage.prop('title');
	const onSubmit = loginPage.prop('onSubmit');
	it('Successful Login', () => {
		const mockedResponse = {
			data: { token: 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZjI2YTlmYy1iYzdmLTRmMmUtODE1NC0yNTUyMjZlNzFjNmIiLCJ1c2VyX2VtYWlsIjoiaGFyc2hhLmJhQHBoaWxpcHMuY29tIiwibmJmIjoxNjg0MTkwMzEwLCJ1c2VyX2lkIjoiYWYyNmE5ZmMtYmM3Zi00ZjJlLTgxNTQtMjU1MjI2ZTcxYzZiIiwidXNlcl9naXZlbl9uYW1lIjoiSGFyc2hhIiwiZXhwIjoxNjg0MTkxMjEwLCJpYXQiOjE2ODQxOTAzMTAsInVzZXJfZmFtaWx5X25hbWUiOiJCQSIsInVzZXJfb3JnYW5pemF0aW9ucyI6eyJtYW5hZ2luZ09yZ2FuaXphdGlvbiI6IjdkZGExMDEzLWM0NjctNDAyNS05NmYyLTZjNjM1M2M0NGE2NyIsIm9yZ2FuaXphdGlvbkxpc3QiOlt7Im9yZ2FuaXphdGlvbklkIjoiN2RkYTEwMTMtYzQ2Ny00MDI1LTk2ZjItNmM2MzUzYzQ0YTY3Iiwib3JnYW5pemF0aW9uTmFtZSI6IkZvY3VzUG9pbnRDbG91ZElvdCIsInBlcm1pc3Npb25zIjpbXSwiZ3JvdXBzIjpbXSwicm9sZXMiOltdfV19fQ.abWJ9WKH4-pIWAqCx-FsBvJy_4dHhZ1YYvkNrLkgUlU' },
			status: 200,
			statusText: 'OK',
			headers: {},
			config: {},
		};
		mockedAxios.post.mockReturnValue(Promise.resolve(mockedResponse));
		expect(title).toEqual('Focalpoint Cloud Monitoring');
		onSubmit('username', 'password');
		expect(mockedAxios.post).toHaveBeenCalled();
	});

	it('Failed Login', () => {
		const mockedResponse = {
			data: { token: '' },
			status: 401,
			statusText: 'Invalid',
			headers: {},
			config: {},
		};
		mockedAxios.post.mockReturnValue(Promise.resolve(mockedResponse));
		expect(title).toEqual('Focalpoint Cloud Monitoring');
		onSubmit('username', 'password');
		expect(mockedAxios.post).toHaveBeenCalled();
	});

	it('Error Token', () => {
		const mockedResponse = {
			data: { token: 'Invalid Token' },
			status: 200,
			statusText: 'Ok',
			headers: {},
			config: {},
		};
		mockedAxios.post.mockReturnValue(Promise.resolve(mockedResponse));
		expect(title).toEqual('Focalpoint Cloud Monitoring');
		onSubmit('username', 'password');
		expect(mockedAxios.post).toHaveBeenCalled();
	});

	it('Validate User Token', () => {
		const mockedResponse = {
			data: { token: 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZjI2YTlmYy1iYzdmLTRmMmUtODE1NC0yNTUyMjZlNzFjNmIiLCJ1c2VyX2VtYWlsIjoiaGFyc2hhLmJhQHBoaWxpcHMuY29tIiwibmJmIjoxNjg0MTkwMzEwLCJ1c2VyX2lkIjoiYWYyNmE5ZmMtYmM3Zi00ZjJlLTgxNTQtMjU1MjI2ZTcxYzZiIiwidXNlcl9naXZlbl9uYW1lIjoiSGFyc2hhIiwiZXhwIjoxNjg0MTkxMjEwLCJpYXQiOjE2ODQxOTAzMTAsInVzZXJfZmFtaWx5X25hbWUiOiJCQSIsInVzZXJfb3JnYW5pemF0aW9ucyI6eyJtYW5hZ2luZ09yZ2FuaXphdGlvbiI6IjdkZGExMDEzLWM0NjctNDAyNS05NmYyLTZjNjM1M2M0NGE2NyIsIm9yZ2FuaXphdGlvbkxpc3QiOlt7Im9yZ2FuaXphdGlvbklkIjoiN2RkYTEwMTMtYzQ2Ny00MDI1LTk2ZjItNmM2MzUzYzQ0YTY3Iiwib3JnYW5pemF0aW9uTmFtZSI6IkZvY3VzUG9pbnRDbG91ZElvdCIsInBlcm1pc3Npb25zIjpbXSwiZ3JvdXBzIjpbXSwicm9sZXMiOltdfV19fQ.abWJ9WKH4-pIWAqCx-FsBvJy_4dHhZ1YYvkNrLkgUlU' },
			status: 200,
			statusText: 'Ok',
			headers: {},
			config: {},
		};
		validateUserSession('someurl');
		mockedAxios.post.mockReturnValue(Promise.resolve(mockedResponse));
		expect(mockedAxios.post).toHaveBeenCalled();
	});

	it('Renew User Token', () => {
		const mockedResponse = {
			data: { token: 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZjI2YTlmYy1iYzdmLTRmMmUtODE1NC0yNTUyMjZlNzFjNmIiLCJ1c2VyX2VtYWlsIjoiaGFyc2hhLmJhQHBoaWxpcHMuY29tIiwibmJmIjoxNjg0MTkwMzEwLCJ1c2VyX2lkIjoiYWYyNmE5ZmMtYmM3Zi00ZjJlLTgxNTQtMjU1MjI2ZTcxYzZiIiwidXNlcl9naXZlbl9uYW1lIjoiSGFyc2hhIiwiZXhwIjoxNjg0MTkxMjEwLCJpYXQiOjE2ODQxOTAzMTAsInVzZXJfZmFtaWx5X25hbWUiOiJCQSIsInVzZXJfb3JnYW5pemF0aW9ucyI6eyJtYW5hZ2luZ09yZ2FuaXphdGlvbiI6IjdkZGExMDEzLWM0NjctNDAyNS05NmYyLTZjNjM1M2M0NGE2NyIsIm9yZ2FuaXphdGlvbkxpc3QiOlt7Im9yZ2FuaXphdGlvbklkIjoiN2RkYTEwMTMtYzQ2Ny00MDI1LTk2ZjItNmM2MzUzYzQ0YTY3Iiwib3JnYW5pemF0aW9uTmFtZSI6IkZvY3VzUG9pbnRDbG91ZElvdCIsInBlcm1pc3Npb25zIjpbXSwiZ3JvdXBzIjpbXSwicm9sZXMiOltdfV19fQ.abWJ9WKH4-pIWAqCx-FsBvJy_4dHhZ1YYvkNrLkgUlU' },
			status: 200,
			statusText: 'Ok',
			headers: {},
			config: {},
		};
		renewSession('someurl', mockedResponse.data.token);
		mockedAxios.post.mockReturnValue(Promise.resolve(mockedResponse));
		expect(mockedAxios.post).toHaveBeenCalled();
	});

	it('Logout User Token', () => {
		const mockedResponse = {
			data: null,
			status: 200,
			statusText: 'Ok',
			headers: {},
			config: {},
		};
		logoutUser('someurl');
		mockedAxios.post.mockReturnValue(Promise.resolve(mockedResponse));
		expect(mockedAxios.post).toHaveBeenCalled();
	});
});
