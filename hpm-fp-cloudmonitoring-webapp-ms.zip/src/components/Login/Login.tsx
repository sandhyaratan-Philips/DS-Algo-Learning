/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Harsha B A
 * Date:        27/03/2023 03:00:00 PM
 *
 **/

import { LoginPage } from '@dls/react-login-page';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { authenticate, validateUserSession, logoutUser } from '../Services/SessionService';
import './Login.scss';
import { environment } from '../../environment/environment';
import { clearSessionCache, setSessionErrorMessage, updateSessionToken } from '../Common/util/util';
import jwt_decode from "jwt-decode";

const Login = () => {
	const navigate = useNavigate();
	const [isValidSession, setIsValidSession] = useState(false);
	const [isLoggingIn, setLoggingIn] = useState(false);
	const { t } = useTranslation('translations', { keyPrefix: 'login' });

	useEffect(() => {
		if (localStorage.getItem('sessionLoggedIn')) {
			if (!sessionStorage.getItem('sessionToken')) {
				checkValidUserLogin();
			} else {
				navigate('/dashboard');
			}
		}
	}, [isValidSession]);

	// Clear error messages on login page refresh event
	window.onbeforeunload = function () {
		localStorage.removeItem('sessionErrorMessage');
	};

	const checkValidUserLogin = () => {
		validateUserSession(`${environment.BASE_URL}/validateCloudUserLoginSession`).then((response) => {
			if (response.status === 200) {
				sessionStorage.setItem('sessionToken', response.data?.token);
				navigate('/dashboard');
			} else {
				invalidateUser();
			}
		}).catch(() => {
			invalidateUser();
		});
	}

	const invalidateUser = () => {
		logoutUser(`${environment.BASE_URL}/logoutCloudUser`);
		setLoggingIn(false);
		clearSessionCache();
		setSessionErrorMessage(t('sessionInvalid'));
		setIsValidSession(false);
	}

	const submitHandler = (username: string, password: string) => {
		setLoggingIn(true);
		authenticate(`${environment.BASE_URL}/authenticateCloudUser`, { loginUserName: username, loginUserKey: password }).then((response) => {
			if (response.status === 200) {
				const token = response.data?.token;
				const decodedToken: any = jwt_decode(token);
				const loginName = `${decodedToken.user_given_name} ${decodedToken.user_family_name}`;
				const currentTimeSecondsInEpoch = Math.round(new Date().getTime() / 1000);
				const idleTimeoutDuration = decodedToken.exp - currentTimeSecondsInEpoch;
				const sessionIdleTime = currentTimeSecondsInEpoch + idleTimeoutDuration;
				setSessionLoginFlags(sessionIdleTime.toString(), loginName, idleTimeoutDuration.toString());
				setIsValidSession(true);
				updateSessionToken(token);
			} else {
				setLoggingIn(false);
				setSessionErrorMessage(t('invalidCredentials'));
			}
		}).catch(() => {
			setLoggingIn(false);
			setSessionErrorMessage(t('invalidCredentials'));
		});
	}

	const setSessionLoginFlags = (sessionIdleTime: string, loginName: string, idleTimeoutDuration: string) => {
		localStorage.setItem('sessionIdleTime', sessionIdleTime);
		localStorage.setItem('sessionLoggedIn', 'true');
		localStorage.setItem('sessionErrorMessage', '');
		localStorage.setItem('sessionUserName', loginName);
		localStorage.setItem('sessionIdleTimeDuration', idleTimeoutDuration);
	}

	return <LoginPage
		title="Focalpoint Cloud Monitoring"
		hasLoginError={localStorage.getItem('sessionErrorMessage') !== '' && localStorage.getItem('sessionErrorMessage') !== null}
		isLoggingIn={isLoggingIn}
		onSubmit={submitHandler}
		loginErrorMessage={localStorage.getItem('sessionErrorMessage') ?? ''}
		ClinicalFooter={() => (
			<div className='copyright'>
				{t('copyrightFormat')}
			</div>
		)}
	/>
};

export default Login;
