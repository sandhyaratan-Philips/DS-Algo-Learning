/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        26/02/2023 10:00:00 AM
 *
 **/
import BarGraph from "../BarGraph/BarGraph";
import { useDispatch, useSelector } from "react-redux";
import { SetDatewiseStatus } from "../../store/actions";
import "./DateWiseStatus.scss";
import { RootState } from "../../store/store";

export default function DateWiseStatus() {
    const dispatch = useDispatch();
    const datewiseStatus = useSelector((state: RootState) => state.list.dateWiseStatus);
    const handleClose = () => {
        dispatch(SetDatewiseStatus(false));
    }
    return (
        <div className="datewise-style">
            <div className="close" onClick={() => { handleClose() }}>x</div>
            <div className="bargraph-style">
            {datewiseStatus && <BarGraph></BarGraph> }
            </div>
        </div>
    );
}
