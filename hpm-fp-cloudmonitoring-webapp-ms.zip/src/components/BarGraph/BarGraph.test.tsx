/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import React from "react";
import { render, screen  } from "@testing-library/react";
import { Provider } from 'react-redux';
import  BarGraph from "./BarGraph";
import store from "../../store/store";
export *  from '../../store/actions/listActions';

describe("BarGraph component to be present in ui", () => {
  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));

    it('bar-graph  to be in the document', () => {
      renderWithContext(<BarGraph/>);
      expect(screen.getByTestId("bar-graph")).toBeInTheDocument;
  });

function renderWithContext(element: React.ReactElement){
  render(
    <Provider store={store}>{element}</Provider>
  )
}
});

