/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import React, { useEffect, useState } from "react";
import "./BarGraph.scss";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { getList } from "../../store/actions";
import CustomWidthTooltip from "@mui/material/Tooltip";
import { Icon } from '@dls/react-icon';
import { Dialog, DialogTitle, DialogContent, DialogContentText } from '@dls/react-mui-dialog';
import { Typography } from '@dls/react-mui-typography';
import axios from "axios";
import Table from 'react-bootstrap/Table';
import { environment } from "../../environment/environment";
import { StatusInfo, ApplicationInfo } from "../../store/types";
import { SetDatewiseStatus } from "../../store/actions";
import Alert from "react-bootstrap/Alert";
import * as  getEndTimeValue from '../Common/util/util';
import { LABEL } from "../Common/constants";

export const BarGraph: React.FunctionComponent = () => {
	const dispatch = useDispatch();
	const list = useSelector((state: RootState) => state.list.lists);
	const selectedAppName = useSelector((state: RootState) => state.list.selectedApplication);
	const [open, setOpen] = useState(false);
	const [displayApplicationName, setDisplayApplicationName] = useState('');
	const [downtime, setDownTime] = useState([{}]);
	const [startTime, setStartTime] = useState('');
	const [endTime, setEndTime] = useState('');
	const [errorMessage, setErrorMessage] = useState('');
	const CLOUD_HEALTH_STATUS_HOURLY_URL = environment.BASE_URL + '/HealthCheck/hourly';

	useEffect(() => {
		dispatch(getList());
	}, [selectedAppName]);

	const handleClickOpen = (applicationInfo: ApplicationInfo, statusItem: StatusInfo) => {
		dispatch(SetDatewiseStatus(true));
		getHourDetails(statusItem.date);
		setDisplayApplicationName(applicationInfo.displayName);
		const endtime = getEndTimeValue.getEndTimeValue(statusItem);
		if (statusItem.status !== "NORECORDS") {
			axios.get(CLOUD_HEALTH_STATUS_HOURLY_URL, {
				params: {
					applicationName: applicationInfo.applicationName,
					start: statusItem.date + 'Z',
					end: endtime + 'Z'
				}, headers: {
					Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
				}
			}).then((response) => {
				setDownTime(response.data.status);

			}).catch(error => {
				setErrorMessage(error.errorCode);

			});
			setTimeout(() => {
				setOpen(true);
			}, 1000);

		}

	};

	const getHourDetails = (localTime: string) => {
		const date = new Date(localTime);
		setStartTime(date.getHours().toString());
		if (date.getHours() === 23) {
			setEndTime('00');
		} else {
			setEndTime((date.getHours() + 1).toString());
		}

	}

	const handleClose = () => {
		setOpen(false);
	};

	if (errorMessage)
		return (
			<div>
				<Alert>{errorMessage}</Alert>
			</div>
		);
	return (
		<div>
			<div className="bar-graph" data-testid="bar-graph">
				{list && list.map((applicationInfo: ApplicationInfo, parentindex: number) => {
					return (
						<div className="bar-list" data-testid="bar-list" key={`${parentindex}_bargraph`}>
							{applicationInfo.status.length === 0 ? <div>No Status is Available</div> : applicationInfo.status.map((statusItem: StatusInfo, index: number) => {
								return (
									<CustomWidthTooltip key={`${index}_bartooltip_${parentindex}`} title={statusItem.status + "\n" + statusItem.date}
										placement="bottom" arrow>
										<div className={statusItem.status} onClick={() => {
											handleClickOpen(applicationInfo, statusItem)
										}}>
										</div>
									</CustomWidthTooltip >
								)
							}

							)}

							<div>
								<Dialog
									open={open}
									onClose={handleClose}
									hideBackdrop
									aria-labelledby="dialog-title"
									aria-describedby="dialog-description">
									<DialogTitle id="dialog-title">
										<Typography className="application-name">{displayApplicationName}</Typography>
										<Icon
											name="Cross"
											size="m"
											className={'dlsIcon header'}
											onClick={handleClose}
										/>
									</DialogTitle>
									<DialogContent>
										<DialogContentText id="dialog-description">
											<Typography variant="body2">
												{downtime.length === 0 ? <div className="table-datastyle"> <p className="table-datastyle">There is No DownTime for hour :<b>{startTime}:00:00 to {endTime}:00:00</b> </p>Application is up and running</div> :
													<div>
														<p className="table-datastyle">DownTime Details for hour :<b>{startTime}:00:00 to {endTime}:00:00</b> </p>
														{errorMessage.length !== 0 ? <div>{errorMessage}</div> :
															<Table striped bordered hover>
																<thead>
																	<tr>
																		<th>From</th>
																		<th>To</th>
																		<th>Duration</th>
																	</tr>
																</thead>
																<tbody>
																	{downtime.map((statusObject: any, index: number) => {
																		return (
																			<tr className="table-datastyle" key={`${index}_bargraph_table`}>
																				<td>{statusObject.from}</td>
																				<td>{statusObject.to ? statusObject.to : <span style={{ color: "red" }}>Actively Down</span>}</td>
																				<td>{statusObject.duration ? statusObject.duration : <span style={{ color: "red" }}></span>}</td>
																			</tr>
																		)
																	})
																	}
																</tbody>
															</Table>
														}
													</div>
												}
											</Typography>
										</DialogContentText>
									</DialogContent>
								</Dialog>
							</div>

						</div>

					);
				})}
				<div className="message"><span>{LABEL.LABEL_DISCLAIMER}</span></div>
			</div>

		</div>
	);
};

export default function BarGraphFunc() {
	return (<BarGraph></BarGraph>)
}