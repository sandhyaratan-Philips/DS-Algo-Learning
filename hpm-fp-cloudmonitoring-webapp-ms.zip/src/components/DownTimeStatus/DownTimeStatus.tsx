/* eslint-disable @typescript-eslint/no-explicit-any */

import Table from 'react-bootstrap/Table';
import { LABEL } from "../Common/constants";

const DownTimeStatus = (props: any) => {
    return (
        <div>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>{LABEL.FROM}</th>
                        <th>{LABEL.TO}</th>
                        <th>{LABEL.DURATION}</th>
                    </tr>
                </thead>
                <tbody>
                    {props.downStatustime.map((statusData: any) => {
                        return (
                            <tr className="table-datastyle" key={statusData.from}>
                                <td>{statusData.from}</td>
                                <td>{statusData.to ? statusData.to : <span style={{ color: "red" }}>Actively Down</span>}</td>
                                <td>{statusData.duration ? statusData.duration : <span style={{ color: "red" }}></span>}</td>
                            </tr>
                        )
                    })
                    }
                </tbody>
            </Table>
        </div>

    );
};
export default DownTimeStatus;