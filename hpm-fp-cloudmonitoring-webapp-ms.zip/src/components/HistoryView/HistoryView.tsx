/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store/store";
import Calendar from "../Calendar/Calendar";
import Spinner from "react-bootstrap/Spinner";
import { getList, setApplicationList, setApplicationName, SearchResultStatus } from "../../store/actions";
import axios from "axios";
import { environment } from "../../environment/environment";
import Alert from "react-bootstrap/Alert";


const HistoryView = () => {
	const dispatch = useDispatch();
	const pageIndex = useSelector((state: RootState) => state.list.queryPageIndex);
	const pageSize = useSelector((state: RootState) => state.list.queryPageSize);
	const [loading, setLoading] = useState(true);
	const [errorMessage, setErrorMessage] = useState('');
	const sort = useSelector((state: RootState) => state.list.sort);
	const CLOUD_HEALTH_STATUS__APPLICATION_URL = environment.BASE_URL + '/HealthCheck/applications';
	const SearchResultFound = useSelector((state: RootState) => state.list.displayStatus);
	const cardName = 'cloud';

	useEffect(() => {
			axios.get(CLOUD_HEALTH_STATUS__APPLICATION_URL,
				{
					params: {
						name: '',
						pageNumber: pageIndex + 1,
						recordsPerPage: pageSize,
						sortingOrder: sort
					}, headers: {
						Authorization: `Bearer ${sessionStorage.getItem('sessionToken')}`
					}
				}
			).then((response) => {
				dispatch(setApplicationName(response.data.data[0].applicationName));
				dispatch(setApplicationList(response.data.data));
				dispatch(getList());
				dispatch(SearchResultStatus(true));
			}).catch(error => {
				setErrorMessage(error.errorMessage);
			})
				.finally(() => {
					setLoading(false);
				});

	}, []);

	if (loading)
		return (
			<div className="spinner-style" data-testid="loading">
				<Spinner animation="border" variant="dark" />
			</div>
		);
	if (errorMessage)
		return (
			<div data-testid="titleTenant" style={{ marginTop: "53px" }}>
				<Alert>{errorMessage}</Alert>
			</div>
		);


	return (
		<div className="history-view-style" data-testid="history-view">
			{SearchResultFound && <Calendar cardName={cardName} />}

		</div>
	);
};
export default HistoryView;
