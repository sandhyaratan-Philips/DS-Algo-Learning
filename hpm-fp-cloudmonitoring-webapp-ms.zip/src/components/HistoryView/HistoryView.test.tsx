/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import HistoryView from './HistoryView';
import store from "../../store/store";

describe('HistoryView component', () => {

  const mockDispatch = jest.fn();

  jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch
  }));

  it("Render HistoryView component", () => {
    renderWithContext(<HistoryView />);
  });
  function renderWithContext(element: React.ReactElement) {
    render(
      <Provider store={store}>{element}</Provider>
    )
  }
});