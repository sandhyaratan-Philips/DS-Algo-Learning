/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * (C) Koninklijke Philips Electronics N.V. 2023 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Harsha B A
 * Date:        08/04/2023 03:00:00 PM
 *
 **/

import { Navigate, Outlet } from "react-router-dom";

const ProtectedRoutes = () => {
	const isLoggedIn = Boolean(localStorage.getItem('sessionLoggedIn')) ?? false;
	return isLoggedIn ? <Outlet /> : <Navigate to='/' />
}

export default ProtectedRoutes;