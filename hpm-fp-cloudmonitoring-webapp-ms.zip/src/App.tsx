/**
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 *
 * Author:      Malati
 * Date:        01/11/2022 10:00:00 AM
 *
 **/

import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Dashboard from './components/Dashboard/Dashboard';
import Navbar from './components/Common/Navbar/Navbar';
import { Route, Routes, useNavigate } from 'react-router-dom';
import Login from './components/Login/Login';
import '../src/i18n/config';
import { renewSession } from './components/Services/SessionService';
import { environment } from './environment/environment';
import { clearSessionCache, getSessionTimeDiff, updateSessionIdleTime, updateSessionToken } from './components/Common/util/util';
import ProtectedRoutes from './ProtectedRoutes';
import { useTranslation } from 'react-i18next';
import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogContentText, DialogActions } from '@dls/react-mui-dialog';
import { Button, Typography } from '@dls/react-core';
import Settings from './components/Settings/Settings';
import { InstallBase } from './components/Common/InstallBase/InstallBase';


function App() {
	const navigate = useNavigate();
	const showPopUpRef = useRef(false);
	const [showPopUp, setShowPopUp] = useState(showPopUpRef.current);
	const { t } = useTranslation('translations', { keyPrefix: 'login' });

	const sessionWatcher = () => {
		watchSessionRenewal();
		watchSessionIdleTime();
	}

	const watchSessionRenewal = () => {
		const token = sessionStorage.getItem('sessionToken') ?? '';
		if (getSessionTimeDiff('sessionRenewTime') <= 180) {
			renewSession(`${environment.BASE_URL}/renewCloudUserToken`, token).then((response) => {
				if (response.status === 200) {
					updateSessionToken(response.data?.token);
				} else {
					localStorage.setItem('sessionErrorMessage', t('sessionInvalid'));
					callLogout();
				}
			}).catch(() => {
				localStorage.setItem('sessionErrorMessage', t('sessionInvalid'));
				callLogout();
			});
		}
		setTimeout(watchSessionRenewal, 120000);
	}

	const watchSessionIdleTime = () => {
		const diff = getSessionTimeDiff('sessionIdleTime');

		if (diff <= 120 && !showPopUpRef.current) {
			showPopUpRef.current = true;
			setShowPopUp(showPopUpRef.current);
		} else if ((diff > 120 || !localStorage.getItem('sessionLoggedIn')) && showPopUpRef.current) {
			showPopUpRef.current = false;
			setShowPopUp(showPopUpRef.current);
		}

		if (localStorage.getItem('sessionIdleTime') && diff <= 0) {
			localStorage.setItem('sessionErrorMessage', t('sessionExpired'));
			callLogout();
		}
		setTimeout(watchSessionIdleTime, 1000);
	}

	const callLogout = () => {
		clearSessionCache();
		navigate('/');
	}

	const resetSessionIdleTime = () => {
		if (localStorage.getItem('sessionLoggedIn')) {
			updateSessionIdleTime(Number(localStorage.getItem('sessionIdleTimeDuration') ?? '0'));
		}
	}

	const logoutCurrentSession = () => {
		sessionStorage.removeItem('sessionToken');
		const errorMessage = localStorage.getItem('sessionErrorMessage') ?? '';
		localStorage.setItem('sessionErrorMessage', errorMessage !== '' ? errorMessage : t('sessionLoggedOut'));
		callLogout();
	}

	const handleClose = () => {
		setShowPopUp(false);
	};

	sessionWatcher();

	return (
		<div onClick={() => {
			resetSessionIdleTime();
			if (!localStorage.getItem('sessionLoggedIn') && sessionStorage.getItem('sessionToken')) {
				logoutCurrentSession();
			}
		}}>
			<Dialog
				open={showPopUp}
				onClose={handleClose}>
				<DialogContent>
					<DialogContentText id="alert-dialog-description">
						<Typography variant="body2">
							{t('sessionIdleMessage')}
						</Typography>
					</DialogContentText>
				</DialogContent>
				<DialogActions>
					<Button onClick={handleClose} dls_variant="primary">
						Ok
					</Button>
				</DialogActions>
			</Dialog>
			<Routes>
				<Route path="/" element={<Login></Login>} />
			</Routes>
			<Routes>
				<Route element={<ProtectedRoutes />}>
					<Route path="/dashboard" element={
						<Container style={{ backgroundColor: '#F5F5F5' }} fluid>
							<Row>
								<Navbar></Navbar>
							</Row>
							<Row>
								<Col></Col>
								<Col><Dashboard></Dashboard></Col>
								<Col></Col>
							</Row>
						</Container>
					} />
					<Route path="/settings" element={<Container style={{ backgroundColor: '#F5F5F5' }} fluid>
						<Row>
							<Navbar></Navbar>
						</Row>
						<Row>
							<Col></Col>
							<Col><Settings></Settings></Col>
							<Col></Col>
						</Row>
					</Container>} />
				</Route>
				<Route path="/InstallBase" element={<InstallBase></InstallBase>} />
				<Route element={<ProtectedRoutes />}>
					<Route path="/InstallBase" element={
						<Container style={{ backgroundColor: '#F5F5F5' }} fluid>
							<Row>
								<Navbar></Navbar>
							</Row>
							<Row>
								<Col></Col>
								<Col><InstallBase></InstallBase></Col>
								<Col></Col>
							</Row>
						</Container>
					} />
				</Route>
			</Routes>
		</div>
	);
}
export default App;
