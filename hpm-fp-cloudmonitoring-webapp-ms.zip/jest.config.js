/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  testEnvironment: "jsdom",
  preset: 'ts-jest',
  globals : {
    'ts-jest':{
      tsconfig : 'tsconfig.jest.json',

    },
  },
  collectCoverage: true,
  setupFilesAfterEnv: ['./src/setupTests.ts'],
  transform: {
    '^.+\\.(ts|tsx)?$': 'ts-jest',
    "^.+\\.(js|jsx)$": "babel-jest",
  },
  moduleNameMapper: {
    ".(css|less|scss)$": "identity-obj-proxy",
  }
};